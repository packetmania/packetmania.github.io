/*
 * PakcteMania https://packetmania.github.io
 *
 * gcc asan-test.c -o asan-test -fsanitize=address -g
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>
/* #include <sanitizer/lsan_interface.h> */

int ga[10] = {1};

int global_buffer_overflow() {
    return ga[10];
}

void heap_leak() {
    int* k = (int *)malloc(10*sizeof(int));
    return;
}

int heap_use_after_free() {
    int* u = (int *)malloc(10*sizeof(int));
    u[9] = 10;
    free(u);
    return u[9];
}

int heap_buffer_overflow() {
    int* h = (int *)malloc(10*sizeof(int));
    h[0] = 10;
    return h[10];
}

int stack_buffer_overflow() {
    int s[10];
    s[0] = 10;
    return s[10];
}

int *gp;

void stack_use_after_return() {
    int r[10];
    r[0] = 10;
    gp = &r[0];
    return;
}

void stack_use_after_scope() {
    {
        int c = 0;
        gp = &c;
    }
    *gp = 10;
    return;
}

void usage(char *name)
{
    char *index = rindex(name, '/');
    fprintf(stderr,
            "\nTest AddressSanitizer\n"
            "usage: %s [ -bfloprs ]\n\n"
            "-b\theap buffer overflow\n"
            "-f\theap use after free\n"
            "-l\theap memory leak\n"
            "-o\tglobal buffer overflow\n"
            "-p\tstack use after scope\n"
            "-r\tstack use after return\n"
            "-s\tstack buffer overflow\n\n",
           	(index == NULL) ? name : index + 1);
}

int main (int argc, char **argv) {
    int c;

    if (argc == 1) {
        usage(argv[0]);
        return 0;
    }

    while ((c = getopt(argc, argv, "bfloprs")) != -1) {
        switch (c) {
        case 'b':
            heap_buffer_overflow();
            break;
        case 'f':
            heap_use_after_free();
            break;
        case 'l':
            heap_leak();
            /* __lsan_do_recoverable_leak_check(); */
            break;
        case 'o':
            global_buffer_overflow();
            break;
        case 'p':
            stack_use_after_scope();
            break;
        case 'r':
            stack_use_after_return();
            printf("Stack use after return: %d\n", *gp);
            break;
        case 's':
            stack_buffer_overflow();
            break;
        case '?':
        default:
            fprintf(stderr, "Unknown option character!\n");
            usage(argv[0]);
            break;
        }
    }
}
