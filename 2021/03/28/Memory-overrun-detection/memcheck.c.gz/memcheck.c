/*
 * PakcteMania https://packetmania.github.io
 */

#include <stdio.h> 
#include <stdlib.h> 
#include <assert.h> 
#include <string.h>
#include <ctype.h>

/*
 * Write a code for malloc wrapper which adds:
 * Header and footer for each memory block - 4 bytes each
 * Fill with header code 0x0D0C0B0A and footer code 0x12345678
 *
 * Write a code for free wrapper:
 * Check for header pattern and flag error if it is overwritten 
 * Free the original memory
 *
 * Write test code to confirm the functions work
 */

#ifndef HDMP_COLS
#define HDMP_COLS 16
#endif

void my_hexdump (void *mem, unsigned int len)
{
    unsigned int i, j, extra;
    extra = (len % HDMP_COLS) ? (HDMP_COLS - len % HDMP_COLS) : 0;
    
    for (i = 0; i < len + extra; i++) {
        if (i % HDMP_COLS == 0) {
            /* print address */
            printf("\n%p: ", mem + i);
        }
 
        if (i < len) {
            /* print hex data */
            printf("%02x ", 0xFF & ((char*)mem)[i]);
        } else {
            /* print 3 space chars for alignment */
            printf("   ");
        }

        if (i % HDMP_COLS == (HDMP_COLS - 1)) {
            /* print ASCII dump */
            for (j = i - (HDMP_COLS - 1); j <= i; j++) {
                if (j >= len) {
                    /* end of block */
                    printf("\n\n");
                    return;
                } else if (isprint(((char*)mem)[j])) {
                    /* printable char */
                    putchar(0xFF & ((char*)mem)[j]);
                } else {
                    /* other char, print '.' instead */
                    putchar('.');
                }
            }
        }
    }
}

/* redzone patterns */
unsigned int header = 0x0D0C0B0A; 
unsigned int footer = 0x12345678; 

void* my_malloc (size_t sz) 
{ 
    void *p = malloc (4 + 4 + sz + 4); 
    *(unsigned int *)p = header; 
    *(unsigned int *)(p + 4) = sz; 
    *(unsigned int*)(p + 8 + sz) = footer; 
    return p + 8; 
} 

void my_check (void *p, size_t sz)
{
    assert(*(unsigned int*)(p - 8) == header); 
    assert(*(unsigned int*)(p - 4) == sz); 
    assert(*(unsigned int *)(p + sz) == footer); 
}

void my_free (void *p) 
{ 
    void *real_p = p - 8; 
    assert(*(unsigned int*)real_p == header); 
    size_t sz = *(unsigned int*)(real_p + 4); 
    assert(*(unsigned int*)(real_p + 8 + sz) == footer); 
    free(real_p); 
} 

void strcpy_test (void)
{
    char *msg = "Hello world!";
    int mlen = strlen(msg);
    char *buffer = my_malloc(mlen);
    strcpy(buffer, msg);
    printf("%s\n", buffer);
    my_hexdump(buffer-8, mlen+12);
    my_free(buffer);
}

int main ()
{ 
    int size = 32; 
    void *ptr = my_malloc(size); 
    printf( "Usable memory start at %p\n", ptr);
    my_hexdump(ptr - 8, size + 12);
    my_check(ptr, size);
    my_free(ptr); 
    printf("Basic test passed!\n"); 

#if 0
    ptr = my_malloc(size); 
    // 3 cases of coruption: header, size, footer 
    *(unsigned int*)(ptr-8)=header+1; 
    *(unsigned int*)(ptr-4)=0; 
    *(unsigned int*)(ptr+size)=footer+1; 
    printf("Freeing, expecting assertion\n"); 
    my_free(ptr); 
#endif

    strcpy_test();
}
