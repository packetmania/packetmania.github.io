/*
 * PakcteMania https://packetmania.github.io
 *
 * gcc sqrts.c -o sqrts -lm
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <assert.h>

#define ERROR_BOUND 1e-6
#define CLOCKS_PER_MSEC (CLOCKS_PER_SEC / 1000.0L)
#define REAL_RANGE 1000


/* integer square root - Newton iteration */
uint32_t isqrt_nwtn(uint32_t a)
{
    uint32_t a1;
    int s, x0, x1;

    if (a <= 1) return a;

    s = 1;
    a1 = a - 1;
    if (a1 > 65535) { s += 8; a1 >>= 16; }
    if (a1 > 255)   { s += 4; a1 >>= 8; }
    if (a1 > 15)    { s += 2; a1 >>= 4; }
    if (a1 > 3)     { s += 1; }

    x0 = 1 << s;                /* first guess 2**s */
    x1 = (x0 + (a >> s)) >> 1;  /* x1 = (x0+a/x0)/2 */
    while (x1 < x0) {
        x0 = x1;
        x1 = (x0 + (a/x0)) >> 1;
    }
    return x0;
}

/* integer square root - bisection method */
uint32_t isqrt_bist(uint32_t a)
{
    uint32_t low, high, mid;

    if (a <= 1) return a;

    low = 1;
    high = (a >> 5) + 8;
    if (high > 65535) high = 65535; /* adjust upper bound */

    while (high >= low) {
        mid = (low + high) >> 1;
        if (mid * mid > a) {
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }
    return high;
}

/* integer square root - shift-and-substract method */
uint32_t isqrt_sfsb(uint32_t a)
{
    uint32_t m, x, b;

    m = 0x40000000;
    x = 0;
    while (m != 0) {
        b = x | m;
        x >>= 1;
        if (a >= b) {
            a -= b;
            x |= m;
        }
        m >>= 2;
    }
    return x;
}

/* test integer square root */
void test_isqrt(void)
{
    uint32_t num, offset, isqr1, isqr2, i;

    /* test a special boundary case */
    num = 4294838221;
    printf("\nInteger Square Root of %u:\n\tNewton iteration\t%u"
           "\n\tBisection method\t%u\n\tShift-and-substract\t%u\n",
           num, isqrt_nwtn(num), isqrt_bist(num), isqrt_sfsb(num));

    /* test perfect and non-perfect square numbers, 1000 each */
    for (int i=0; i<1000; i++) {
        num = random() & 0xFFFF; /* random 16-bit integer */
        offset = (random() & 0xFFFF) % num;
        isqr1 = num * num; /* test perfect square */
        isqr2 = num * num + offset;
        assert(isqrt_nwtn(isqr1) == num);
        assert(isqrt_nwtn(isqr2) == num);
        assert(isqrt_bist(isqr1) == num);
        assert(isqrt_bist(isqr2) == num);
        assert(isqrt_sfsb(isqr1) == num);
        assert(isqrt_sfsb(isqr2) == num);
    }
    printf("Integer Square Root function test passes!\n");
}

/*
 * measure integer square root execution time and
 * compare the performance between Newton method
 * and bisection method
 */
void measure_isqrt(void)
{
    uint32_t num, isqr, offset, root1, root2, root3;
    clock_t t;
    double nwtn_t = 0, bist_t = 0, sfsb_t = 0;
    
    printf("\nInteger Square Root speed test:\n");

    for (int i=0; i<1000; i++) {
        num = random() & 0xFFFF; /* random 16-bit integer */
        offset = (random() & 0xFFFF) % num;
        isqr = num * num + offset;
        t = clock();
        root1 = isqrt_nwtn(isqr);
        nwtn_t += ((double)(clock() - t)) / CLOCKS_PER_MSEC;
        t = clock();
        root2 = isqrt_bist(isqr);
        bist_t += ((double)(clock() - t)) / CLOCKS_PER_MSEC;
        t = clock();
        root3 = isqrt_sfsb(isqr);
        sfsb_t += ((double)(clock() - t)) / CLOCKS_PER_MSEC;
        assert(root1 == root2);
        assert(root1 == root3);
    }
    printf("\tNewton iteration\t%fms\n\tBisection method\t%fms\n"
           "\tShift-and-substract\t%fms\n", nwtn_t, bist_t, sfsb_t);
}


/* real number square root - bisection method */
float rsqrt_bist(float x)
{
    float low, high, mid;

    /* set initial lower and upper bounds */
    if (x > 1) {
        low = 1;
        high = x;
    } else {
        /* square root of any number less than 1 is bigger
         * than the number itself, e.g. 0.01^0.5 = 0.1 */
        low = x;
        high = 1;
    }

    while ((high - low) > ERROR_BOUND) {
        mid = (high + low) / 2;
        if (mid == low) {
            break; /* force exit */
        }

        if (mid * mid > x) {
            high = mid;
        } else {
            low = mid;
        }
    }
    return mid;
}

/* real number square root - Newton/Babylonian */
float rsqrt_nwtn(float x)
{
    float val = x;
    float last = 1;
    while (fabs(val - last) > ERROR_BOUND) {
        val = (val + last) / 2;
        last = x / val;
    }
    return val;
}

/* test real number square root */
void test_rsqrt()
{
    float num, r0, r1, r2;
    printf("\nNumber\t\tGlibc library sqrt\tNewton iteration\tBisection method\n");
    num = 0.0002; /* test sequence: 0.0002, 0.02, 2, 200, 20000 */
    for (int i=1; i<6; i++) {
        r0 = sqrt(num);
        r1 = rsqrt_nwtn(num);
        r2 = rsqrt_bist(num);
        printf("%-10.4f\t%.15f\t%.15f\t%.15f\n", num, r0, r1, r2);
        assert(r0 - r1 < ERROR_BOUND);
        assert(r0 - r2 < ERROR_BOUND);
        num *= 100;
    }
    printf("Real Number Square Root function test passes!\n");
}


/* fast inverse square root function for 32-bit IEEE 754
 * standard floating-point numerical value */
float fast_inv_sqrt(float x)
{
    float halfx = 0.5f * x;
    int i = *(int *)&x; /* transfer bits of float to int */
    i = 0x5f375a86 - (i >> 1); /* initial guess with magic */
    x = *(float *)&i; /* bit transfer back to float */ 
    x = x * (1.5f - halfx * x * x); /* Newton step */
    x = x * (1.5f - halfx * x * x); /* Repeat (optional) */
    return x;
}

/* measure fast inverse square root accuracy */
void measure_invsqrt(void)
{
    float real, rt, ir1, ir2, acu;

    printf("\nInverse Square Root accuracy test:\n");
    printf("Real Number\t1/sqrt()\tFast-InvSqrt\tError\n");
    for (int i=0; i<10; i++) {
        real = (float)random()/(float)(RAND_MAX/REAL_RANGE);
        rt = sqrt(real);
        ir1 = 1 / rt;
        ir2 = fast_inv_sqrt(real);
        acu = fabs(ir2 * rt - 1); /* relative error */
        printf("%f\t%.8f\t%.8f\t%.8f\n", real, ir1, ir2, acu);
    }
}


int main ()
{
    srandom(time(NULL));
    test_isqrt();
    measure_isqrt();
    test_rsqrt();
    measure_invsqrt();
    return 0;
}
