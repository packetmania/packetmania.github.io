#include "simulation.h"
#include <sys/select.h>
#include <sys/time.h>

#define DEBUG_ID 100

struct Dis_matrix {
  int distance;
  int headId;
};

struct RtableEntry {
  int dest;
  int cost;
  int nexthop;
  int head;
};

int Bind(int *udpsockfd);
int readable_timeout(int fd, int sec);

void FormatMsg(char *send, int neiId, RtableEntry *tem, int numNode, int id);
void PrintRoutingTable(int numDest,int r_id, RtableEntry *rtEntry_old);
bool IN_PATH(int NB, int dest, RtableEntry *table,int id);

void UpdateDisMatrix(char* recv, Dis_matrix **Entry,int numNode, int id,
                     int numNeighbor, nb_tuple *tup);
void sendoutRT(struct sockaddr_in *neibaddr,int numNeighbor,int numNode ,
               RtableEntry *table,nb_tuple *tup, int id, int udpsockfd);
bool compareRT(RtableEntry *oldRT, RtableEntry *newRT, int numNode); 
void OutputRT(RtableEntry *rtEntry_old, int r_id, int numDest);
void CreateRTfromDM(RtableEntry *rtEntry_new, Dis_matrix **Entry, 
                    nb_tuple *tup, int numDest, int numNB);


// create an UDP socket then bind, return UDP port number used
int Bind (int *udpsockfd)
{
    socklen_t size;
    struct sockaddr_in my_addr;
    if ((*udpsockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
        perror("socket error");
        exit(1);
    }

    my_addr.sin_family = AF_INET;        
    my_addr.sin_port = htons(0);    
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
 
    if (bind(*udpsockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr))
        == -1) {
        perror("bind error"); 
        exit(1);
    }
    size = sizeof(struct sockaddr_in);
    if (getsockname(*udpsockfd, (struct sockaddr *)&my_addr, &size) < 0) {
        perror("getsockname error");
        exit(1);
    }
    return my_addr.sin_port;
}

int readable_timeout (int fd, int sec)
{
    fd_set rset;
    struct timeval tv;
  
    FD_ZERO(&rset);
    FD_SET(fd, &rset);
    
    tv.tv_sec=sec;
    tv.tv_usec=0;
  
    return (select(fd+1, &rset, NULL, NULL, &tv));
}
  
void FormatMsg (char *send, int neiId, RtableEntry *tem, int numNode, int id)
{
    char temp[2*MAXLEN];
    sprintf(send,"%d %d %d*", id, neiId, numNode);
    
    for (int i=0; i<numNode; i++) {
        sprintf(temp,"%d %d %d#",tem[i].dest, tem[i].cost, tem[i].head);
        strcat(send, temp);
    }
}

void PrintDisMatrix (int nd, int nb, nb_tuple *tup, Dis_matrix **entry) 
{
    cout<<"R"<<DEBUG_ID<<" Distance Matrix:"<<endl;
    cout<<"Dest\tNextHop\tDist\tHead"<<endl;
    for (int i=0; i<nd; i++) {
        for (int j=0; j<nb; j++) {   
            cout<<i<<"\t"<<tup[j].neighborId<<"\t"<<entry[i][j].distance
                <<"\t"<<entry[i][j].headId<<endl;
        }
    }
}

void PrintRoutingTable (int numDest, int r_id, RtableEntry *rtEntry_old)
{
    cout<<"R"<<DEBUG_ID<<" Routing Table:"<<endl;
    cout<<"Dest\tCost\tNextHop\tHead"<<endl;
    for (int i=0; i<numDest; i++)
        cout<<rtEntry_old[i].dest<<"\t"<<rtEntry_old[i].cost<<"\t"
            <<rtEntry_old[i].nexthop<<"\t"<<rtEntry_old[i].head<<endl;
}  

bool IN_PATH (int NB, int dest, RtableEntry *table, int id)
{
    int head=table[dest].head;
    if (head==-1)
        return false;
  
    while ((head!=id) && (head!=NB) && (head!=-1))
        head=table[head].head;
    
    if (head==id || head==-1) return false;
    else return true;
}

void UpdateDisMatrix (char* recv, Dis_matrix **Entry,int numNode, int id,
                      int numNeighbor, nb_tuple *tup)
{
    int sour, dest, tempDest, tempDist, tempHead, i, j, k;
    char *temp;
    
    temp=strchr(recv,'*')+1;
    sscanf(recv,"%d %d %d*",&sour,&dest,&numNode);
  
    for (i=0;i<numNode;i++) {
        sscanf(temp,"%d %d %d",&tempDest,&tempDist,&tempHead);
        temp=strchr(temp,'#')+1;
  
        if ((tempDest==id)||(tempDest==sour))
            continue;

        for (j=0; j<numNode; j++) {
            if (j==tempDest) {
                for (k=0;k<numNeighbor; k++)
                    if (tup[k].neighborId==sour)
                        break;
                if (tempDist==-1) {
                    Entry[j][k].distance=-1;
                    Entry[j][k].headId=-1;
                } else {
                    Entry[j][k].distance=tempDist+tup[k].cost;
                    Entry[j][k].headId=tempHead;
                }
                break;
            }
        }
    }
}

void sendoutRT (struct sockaddr_in *neibaddr,int numNeighbor,int numNode,
                RtableEntry *table, nb_tuple *tup, int id, int udpsockfd) 
{
    int i, j;
    RtableEntry *tmpRT;
    char buffer[2*MAXLEN];
  
    for (j=0; j<numNeighbor; j++) {
        tmpRT=new RtableEntry[numNode];
      
        for (i=0; i<numNode; i++) {
            if (IN_PATH(tup[j].neighborId, i, table, id)) {
                tmpRT[i].cost=-1;
                tmpRT[i].head=-1;
                tmpRT[i].dest=i;
            } else {
                tmpRT[i].cost=table[i].cost;
                tmpRT[i].head=table[i].head;
                tmpRT[i].dest=i;
            }
        }
  
        FormatMsg(buffer,tup[j].neighborId, tmpRT,numNode, id);
        delete tmpRT;
  
        sendto(udpsockfd, buffer, strlen(buffer), 0,
               (struct sockaddr *)&(neibaddr[j]), sizeof(struct sockaddr));
    }
}

bool compareRT (RtableEntry *oldRT, RtableEntry *newRT, int numNode)
{
    for (int i=0; i<numNode; i++) {
        if (oldRT[i].cost != newRT[i].cost ||
            oldRT[i].nexthop != newRT[i].nexthop ||
            oldRT[i].head!=newRT[i].head)
            return true;
    }
    return false;
}

void OutputRT (RtableEntry *rtEntry_old, int r_id, int numDest)
{
    FILE *fp1;
    char filename[10];
    int head;
  
    sprintf(filename, "%d", r_id);
    if ((fp1 = fopen(filename, "w")) == NULL) {
        cout<<"Can not create the file "<<r_id<<endl;
        exit(1);
    }
    
    int i;
    for (i=0; i<numDest; i++) {
        if (i==r_id) fprintf(fp1, "%d -1 0\n", i);
        else {
            fprintf(fp1, "%d %d %d %d,",
                    rtEntry_old[i].dest, rtEntry_old[i].nexthop,
                    rtEntry_old[i].cost, rtEntry_old[i].dest);
            head = rtEntry_old[i].head;
    
            while (head != r_id && head != -1) {
                fprintf(fp1, "%d,", head);
                head = rtEntry_old[head].head;
            }
    
            fprintf(fp1, "%d\n", head);
        }
    }
    
    fclose(fp1);
}

void CreateRTfromDM (RtableEntry *rtEntry_new, Dis_matrix **Entry,
                     nb_tuple *tup, int numDest, int numNB)
{
    int i,j, tmp, k;
   
    for (i=0; i<numDest; i++) {
        tmp=Entry[i][0].distance;
        k=0;
        for (j=1;j<numNB; j++) {
            if (Entry[i][j].distance==-1)
                continue;
            else if (tmp==-1||Entry[i][j].distance<tmp) {
                tmp=Entry[i][j].distance;
                k=j;
            }
        }
        rtEntry_new[i].dest=i;
        rtEntry_new[i].cost=tmp;
        rtEntry_new[i].nexthop=tup[k].neighborId;
        rtEntry_new[i].head=Entry[i][k].headId;
    }
}

void router (int id, int sockId, int numNode)
{
    int sockfd, myport, i, j;
    socklen_t len;
    char hostname[HNAMELEN];
    struct sockaddr_in servaddr, *neibaddr;
    struct hostent *hp;
    char meg[MAXLEN];
    message msg;
    nb_tuple *tup;
    char *RT_header[MAXLEN];
    char recvline[MAXLEN+1];
    char item[MAXLEN];
    char sendline[2*MAXLEN];
    int udpsockfd;

    //address information
    sockfd=socket(AF_INET, SOCK_STREAM, 0);
    servaddr.sin_family=AF_INET;
   
    // connect to the manager
    len = sizeof(servaddr);
    getsockname(sockId, (struct sockaddr *)&servaddr, &len);
    connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
    
    //send UDP port number to manager
    myport=Bind(&udpsockfd);
    len=sprintf(meg, "%d %d",id,myport);
    send(sockfd, meg, len, 0);
     
    // receive info from manager
    read(sockfd, &msg, sizeof(struct message));
    tup=new nb_tuple[msg.numNeighbor];
    read(sockfd, tup ,sizeof(struct nb_tuple)*msg.numNeighbor);
    close(sockfd);

    // initialize neighbor socket addresses for send routing table
    neibaddr = new sockaddr_in[msg.numNeighbor];
    for (i=0; i<msg.numNeighbor; i++) {
        neibaddr[i].sin_family = AF_INET;   
        /*
         * On Sun SPARC system, should call htons() for UDP port, while
         * on Intel based system no such need. Calling it would actually 
         * create problem. Learned it hard way on macOS with x86_64.
         */
        neibaddr[i].sin_port = tup[i].UDP_port;
        neibaddr[i].sin_addr.s_addr = htonl(INADDR_ANY);
    }

    if (id == DEBUG_ID)
        for (i=0; i<msg.numNeighbor; i++) {
            cout<<"neighborId "<<tup[i].neighborId<<": cost "<<tup[i].cost
                <<", UDP_port "<<tup[i].UDP_port<<endl;
        }

    // create distance matrix entries
    Dis_matrix **entry;
    entry = new Dis_matrix*[numNode];
    
    // initialize distance matrix
    for (i=0; i<numNode; i++) {
        entry[i] = new Dis_matrix[msg.numNeighbor];
        for (j=0; j<msg.numNeighbor; j++) {
            if (tup[j].neighborId==i) {
                entry[i][j].distance=tup[j].cost;
                entry[i][j].headId=id;
            } else {
                entry[i][j].distance=-1;
                entry[i][j].headId=-1;
            }
        }
    }
     
    // initialize routing table
    RtableEntry *table=new RtableEntry[numNode];
    for (i=0; i<numNode; i++) {
        int tmp_cost = -1;
        int tmp_next = tup[0].neighborId; 
        int tmp_head = -1;
        for (j=0; j<msg.numNeighbor; j++) {
            if (entry[i][j].distance != -1) {
                tmp_cost = entry[i][j].distance;
                tmp_head = entry[i][j].headId;
                tmp_next = tup[j].neighborId;
                break;
            }
        }
        table[i].dest = i;
        table[i].cost = tmp_cost;
        table[i].nexthop = tmp_next;
        table[i].head = tmp_head;
    }

    // print out distance matrix and routing table
    if (id == DEBUG_ID) {
        PrintDisMatrix(numNode, msg.numNeighbor, tup, entry);
        PrintRoutingTable(numNode, id, table);
    }

    cout<<"R"<<id<<" begin routing"<<endl;
     
    // send a first message with routing entries to each neighbor
    for (i=0;i<msg.numNeighbor;i++) {
        FormatMsg(sendline, tup[i].neighborId, table, numNode, id);
        if (id == DEBUG_ID)
            cout<<"R"<<id<<" sends 1st msg to R"<<tup[i].neighborId
                <<":"<<sendline<<endl;
        if (sendto(udpsockfd, sendline, strlen(sendline),0, 
            (struct sockaddr *)&(neibaddr[i]), sizeof(struct sockaddr))==-1)
            cout<<"Error with sendto R"<<tup[i].neighborId<<"!"<<endl;
    }

    int p;
    while ((p=readable_timeout(udpsockfd, numNode*3)) > 0) {
        int n=recvfrom(udpsockfd, recvline, MAXLEN,0,NULL,NULL);
        recvline[n]=0;

        if (id == DEBUG_ID)
            cout<<"R"<<id<<" recv="<<recvline<<endl;
  
        // update Distance Matrix
        UpdateDisMatrix(recvline, entry, numNode, id, msg.numNeighbor, tup);
  
        // creat new routing table from Distance Matrix
        RtableEntry *rtEntry_new=new RtableEntry[numNode];
        CreateRTfromDM(rtEntry_new, entry, tup, numNode, msg.numNeighbor);
  
        if (compareRT(table, rtEntry_new,numNode)==true) {
            delete[] table;
            table=rtEntry_new;
            if (id == DEBUG_ID) {
                cout<<"R"<<id<<" routine table updated"<<endl;
                PrintRoutingTable(numNode, id, rtEntry_new);
            }
            sendoutRT(neibaddr, msg.numNeighbor, numNode, table, tup,
                      id, udpsockfd);
        }
    }
    
    if (p==0) {
        OutputRT(table, id, numNode);
        close(udpsockfd);
        cout<<"R"<<id<<" timeout!"<<endl;
        exit(0);
    } else {
        cout<<"Error with select()!"<<endl;
        exit(1);
    }
}

