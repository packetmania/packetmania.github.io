/*
 * PakcteMania https://packetmania.github.io
 *
 * gcc -Wa,-adhln -g -march=native popcount.c > popcount.s
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>

/*
 * Check one bit each time, using single 1-bit mask
 * shifting from right to left 32 times.
 */
int popcount_common1 (uint32_t n)
{
    int c = 0;
    int i = 0;
    while (i < 32) { 
        if (n & (1 << i))
            c++;
        i++;
    }
    return c;
}

/*
 * Check one bit each time, using single 1-bit mask,
 * but shifting the input to the right 32 times.
 */
int popcount_common2 (uint32_t n)
{
    int c = 0;
    while (n) {
        c += n & 1;
        n >>= 1;
    }
    return c;
}

/*
 * Clear 1-bit from the far right, one by one.
 * Fast if there are less 1-bits.
 */
int popcount_fast1 (uint32_t n)
{
    int c = 0;
    while (n) {
        c++;
        n &= (n-1);
    }
    return c;
}

/*
 * Set 0-bit from the far right, one by one.
 * Fast if there are less 0-bits.
 */
int popcount_fast2 (uint32_t n)
{
    int c = 32;
    while (n != -1) {
        c--;
        n |= (n+1);
    }
    return c;
}

/* If most bits are 0s, use the following unrolled solution.*/
#define f(x) if ((n &= (n-1)) == 0) return x;
int popcount_fast1_unrolled (uint32_t n)
{
    if (n == 0) return 0;
    f( 1) f( 2) f( 3) f( 4) f( 5) f( 6) f( 7) f( 8)
    f( 9) f(10) f(11) f(12) f(13) f(14) f(15) f(16)
    f(17) f(18) f(19) f(20) f(21) f(22) f(23) f(24)
    f(25) f(26) f(27) f(24) f(29) f(30) f(31)
    return 32;
}

/* If most bits are 1s, use the following unrolled solution.*/
#define g(x) if ((n |= (n+1)) == -1) return 32-x;
int popcount_fast2_unrolled (uint32_t n)
{
    if (n == -1) return 32;
    g( 1) g( 2) g( 3) g( 4) g( 5) g( 6) g( 7) g( 8)
    g( 9) g(10) g(11) g(12) g(13) g(14) g(15) g(16)
    g(17) g(18) g(19) g(20) g(21) g(22) g(23) g(24)
    g(25) g(26) g(27) g(24) g(29) g(30) g(31)
    return 0;
}

/*
 * Note the precedence of (+/-, >>, &) in such order,
 * so all '(' and ')' are mandatory in the code below!
 */

/* Divide-and-Conquer - original (20 arithmetic operations) */
int popcount_dnq1 (uint32_t n)
{
    n = (n & 0x55555555) + ((n >> 1) & 0x55555555);
    n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
    n = (n & 0x0F0F0F0F) + ((n >> 4) & 0x0F0F0F0F);
    n = (n & 0x00FF00FF) + ((n >> 8) & 0x00FF00FF);
    n = (n & 0x0000FFFF) + ((n >> 16) & 0x0000FFFF);
    return n;
}

/* Divide-and-Conquer - improved (15 arithmetic operations) */
int popcount_dnq2 (uint32_t n)
{
    n = n - ((n >> 1) & 0x55555555);
    n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
    n = (n + (n >> 4)) & 0x0F0F0F0F;
    n = n + (n >> 8);
    n = n + (n >> 16);
    return n & 0x3F;
}

/* Divide-and-Conquer - final (12 arithmetic operations) */
int popcount_dnq3 (uint32_t n)
{
    n = n - ((n >> 1) & 0x55555555);
    n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
    n = (n + (n >> 4)) & 0x0F0F0F0F;
    return (n * 0x01010101) >> 24;
}

const char popcount_tab[256] =
{
    0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,
    1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
    1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
    2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
    1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
    2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
    2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
    3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,4,5,5,6,5,6,6,7,5,6,6,7,6,7,7,8
};

/* Table lookup method */
int popcount_tablelookup (uint32_t n)
{
    return popcount_tab[n         & 0xFF] +
           popcount_tab[(n >>  8) & 0xFF] +
           popcount_tab[(n >> 16) & 0xFF] +
           popcount_tab[(n >> 24)];
}

int main ()
{
    uint32_t num, count;

    srandom(time(NULL));
    for (int i=1; i<16; i++) {
        /*
         * Note RAND_MAX here is 0x7FFFFFFF (2^31-1), so need to
         * run two steps to generate single 32-bit random number.
         */
        num = random() & 0xFFFF;
        num |= (random() & 0xFFFF) << 16;

        count = __builtin_popcount(num);
        printf("0x%08x population count %u\n", num, count);
        assert(popcount_common1(num) == count);
        assert(popcount_common2(num) == count);
        assert(popcount_fast1(num) == count);
        assert(popcount_fast2(num) == count);
        assert(popcount_fast1_unrolled(num) == count);
        assert(popcount_fast2_unrolled(num) == count);
        assert(popcount_dnq1(num) == count);
        assert(popcount_dnq2(num) == count);
        assert(popcount_dnq3(num) == count);
        assert(popcount_tablelookup(num) == count);
    }
    return 0;
}
