#include "simulation.h"


extern void router(int id, int tcp_port, int numNode);

struct neighbor {
    int id;
    int cost;
    neighbor *next;
};
   
struct source {
    int id;
    int numNeighbor;
    neighbor *link;
};

struct tab_1 {
    int nodeId;
    int connId;
    int portNum;
};


int main(int argc, char **argv)
{
    int numNode, sour, dest, cost, i, j, id;
    FILE  *fp,  *po;
    neighbor *ne1, *ne2; // node variables
  
    pid_t childpid;

    int listenfd, connfd, portNum;
    socklen_t clilen;
    char hostname[HNAMELEN];
    struct sockaddr_in cliaddr, servaddr;
    struct hostent *hp;
    message msg;
    nb_tuple *tup;
  
    if (argc!=2) {
        fprintf(stderr, "Please enter topology file name\n");
        exit(1);
    }
  
    if ((fp=fopen(argv[1], "r"))==NULL) {
        perror(argv[1]);
        exit(1);
    }
  
    fscanf(fp, "%d", &numNode);
    cout<<"numnode is: "<< numNode<<endl; 
  
    // initilize the adjacent list
    source *node = new source[numNode];
    for (int i=0; i<numNode; i++) {
        node[i].link=NULL;
        node[i].id =i;
        node[i].numNeighbor=0;
    }
  
    // read topology file and construct the adjacency list
    while (fscanf(fp,"%d %d %d",&sour, &dest, &cost)!=EOF) {
        ne1 = new neighbor;
        ne2 = new neighbor;
        ne1->id = sour;
        ne1->cost = cost;
        ne1->next = NULL;
        ne2->id = dest;
        ne2->next = NULL;
        ne2->cost = cost;
      
        if (node[sour].link == NULL) { 
            // insert the first neighbor to the node list
            node[sour].link = ne2;
        } else {
            // node exists, insert its neighor to the linked list
            ne2->next = node[sour].link;
            node[sour].link = ne2;
        }
    
        if (node[dest].link == NULL) {
            // insert the second neighbor to the node list
            node[dest].link = ne1;
        } else {
            // node exists, insert its neighor to the linked list
            ne1->next = node[dest].link;
            node[dest].link = ne1;
        }
        node[sour].numNeighbor++;
        node[dest].numNeighbor++;
    }
    fclose(fp); 
  
    // print the topology adjacency list
    for (int i=0; i<numNode; i++) {
        cout<<node[i].id<<" " << node[i].numNeighbor<<": ";
        ne1 = node[i].link;
        
        while(ne1->next != NULL) {
            cout<< ne1->id << "."<<ne1->cost<<" ";
            ne1=ne1->next;
        }
        cout<< ne1->id << "."<<ne1->cost<<" ";
        cout << endl;
    }
    
    //address information
    listenfd=socket(AF_INET, SOCK_STREAM, 0);
  
    servaddr.sin_family=AF_INET;
    servaddr.sin_port=htons(0);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
     
    bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
    listen(listenfd, numNode);
        
    // fork the routers
    for (i = 0; i <numNode; i++) {
        if ((childpid = fork())==0) {
           router(i, listenfd, numNode);
           exit(0);
        } 
    }
  
    //receive routers' UDP port number one by one
    tab_1 *t1 =new tab_1[numNode];
    
    po=fopen("ports","w");
    for (i=0; i<numNode; i++) {
        clilen = sizeof(cliaddr);
        connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &clilen);
       
        char temp[MAXLEN];
        read(connfd, temp, 9); 
        sscanf(temp,"%d %d", &id, &portNum);
       
        // set the UDP number in the table
        t1[id].nodeId=id;
        t1[id].portNum=portNum;
        t1[id].connId=connfd;
        //cout<<t1[id].nodeId<<" "<<t1[id].portNum<<endl;
        fprintf(po,"%d %d\n",t1[id].nodeId, t1[id].portNum);
    }  
    fclose(po);
    
    for (i=0; i<numNode; i++) {
        msg.routerId=i;
        msg.numNeighbor=node[i].numNeighbor;
  
        // write header msg including router ID and number of neighbors
        write(t1[i].connId, (char *) &msg, sizeof(struct message));
   
        // write nb_tuples of each neighbor's info 
        nb_tuple *tup=new nb_tuple[msg.numNeighbor];
        ne1=node[i].link;
      
        for (j=0; j<msg.numNeighbor; j++) {
            tup[j].neighborId=ne1->id;
            tup[j].cost=ne1->cost;
            tup[j].UDP_port=t1[ne1->id].portNum;
            ne1=ne1->next;
        }
        
        write(t1[i].connId,(char *)tup, 
              sizeof(struct nb_tuple)*msg.numNeighbor);
        close(t1[i].connId);
    }
    close(listenfd);
    
    // wait for all child processes done
    for (i=0; i<numNode; i++)
        wait(NULL);
}

