   1              		.file	"popcount.c"
   2              		.text
   3              	.Ltext0:
   4              		.globl	popcount_common1
   6              	popcount_common1:
   7              	.LFB6:
   8              		.file 1 "popcount.c"
   1:popcount.c    **** #include <stdio.h>
   2:popcount.c    **** #include <stdint.h>
   3:popcount.c    **** #include <stdlib.h>
   4:popcount.c    **** #include <time.h>
   5:popcount.c    **** #include <assert.h>
   6:popcount.c    **** 
   7:popcount.c    **** /*
   8:popcount.c    ****  * Check one bit each time, using single 1-bit mask
   9:popcount.c    ****  * shifting from right to left 32 times.
  10:popcount.c    ****  */
  11:popcount.c    **** int popcount_common1 (uint32_t n)
  12:popcount.c    **** {
   9              		.loc 1 12 1
  10              		.cfi_startproc
  11 0000 F30F1EFA 		endbr64
  12 0004 55       		pushq	%rbp
  13              		.cfi_def_cfa_offset 16
  14              		.cfi_offset 6, -16
  15 0005 4889E5   		movq	%rsp, %rbp
  16              		.cfi_def_cfa_register 6
  17 0008 897DEC   		movl	%edi, -20(%rbp)
  13:popcount.c    ****     int c = 0;
  18              		.loc 1 13 9
  19 000b C745F800 		movl	$0, -8(%rbp)
  19      000000
  14:popcount.c    ****     int i = 0;
  20              		.loc 1 14 9
  21 0012 C745FC00 		movl	$0, -4(%rbp)
  21      000000
  15:popcount.c    ****     while (i < 32) { 
  22              		.loc 1 15 11
  23 0019 EB1B     		jmp	.L2
  24              	.L4:
  16:popcount.c    ****         if (n & (1 << i))
  25              		.loc 1 16 20
  26 001b 8B45FC   		movl	-4(%rbp), %eax
  27 001e BA010000 		movl	$1, %edx
  27      00
  28 0023 89C1     		movl	%eax, %ecx
  29 0025 D3E2     		sall	%cl, %edx
  30 0027 89D0     		movl	%edx, %eax
  31              		.loc 1 16 15
  32 0029 2345EC   		andl	-20(%rbp), %eax
  33              		.loc 1 16 12
  34 002c 85C0     		testl	%eax, %eax
  35 002e 7403     		je	.L3
  17:popcount.c    ****             c++;
  36              		.loc 1 17 14
  37 0030 FF45F8   		incl	-8(%rbp)
  38              	.L3:
  18:popcount.c    ****         i++;
  39              		.loc 1 18 10
  40 0033 FF45FC   		incl	-4(%rbp)
  41              	.L2:
  15:popcount.c    ****         if (n & (1 << i))
  42              		.loc 1 15 11
  43 0036 837DFC1F 		cmpl	$31, -4(%rbp)
  44 003a 7EDF     		jle	.L4
  19:popcount.c    ****     }
  20:popcount.c    ****     return c;
  45              		.loc 1 20 12
  46 003c 8B45F8   		movl	-8(%rbp), %eax
  21:popcount.c    **** }
  47              		.loc 1 21 1
  48 003f 5D       		popq	%rbp
  49              		.cfi_def_cfa 7, 8
  50 0040 C3       		ret
  51              		.cfi_endproc
  52              	.LFE6:
  54              		.globl	popcount_common2
  56              	popcount_common2:
  57              	.LFB7:
  22:popcount.c    **** 
  23:popcount.c    **** /*
  24:popcount.c    ****  * Check one bit each time, using single 1-bit mask,
  25:popcount.c    ****  * but shifting the input to the right 32 times.
  26:popcount.c    ****  */
  27:popcount.c    **** int popcount_common2 (uint32_t n)
  28:popcount.c    **** {
  58              		.loc 1 28 1
  59              		.cfi_startproc
  60 0041 F30F1EFA 		endbr64
  61 0045 55       		pushq	%rbp
  62              		.cfi_def_cfa_offset 16
  63              		.cfi_offset 6, -16
  64 0046 4889E5   		movq	%rsp, %rbp
  65              		.cfi_def_cfa_register 6
  66 0049 897DEC   		movl	%edi, -20(%rbp)
  29:popcount.c    ****     int c = 0;
  67              		.loc 1 29 9
  68 004c C745FC00 		movl	$0, -4(%rbp)
  68      000000
  30:popcount.c    ****     while (n) {
  69              		.loc 1 30 11
  70 0053 EB13     		jmp	.L7
  71              	.L8:
  31:popcount.c    ****         c += n & 1;
  72              		.loc 1 31 16
  73 0055 8B45EC   		movl	-20(%rbp), %eax
  74 0058 83E001   		andl	$1, %eax
  75 005b 89C2     		movl	%eax, %edx
  76              		.loc 1 31 11
  77 005d 8B45FC   		movl	-4(%rbp), %eax
  78 0060 01D0     		addl	%edx, %eax
  79 0062 8945FC   		movl	%eax, -4(%rbp)
  32:popcount.c    ****         n >>= 1;
  80              		.loc 1 32 11
  81 0065 D16DEC   		shrl	-20(%rbp)
  82              	.L7:
  30:popcount.c    ****     while (n) {
  83              		.loc 1 30 11
  84 0068 837DEC00 		cmpl	$0, -20(%rbp)
  85 006c 75E7     		jne	.L8
  33:popcount.c    ****     }
  34:popcount.c    ****     return c;
  86              		.loc 1 34 12
  87 006e 8B45FC   		movl	-4(%rbp), %eax
  35:popcount.c    **** }
  88              		.loc 1 35 1
  89 0071 5D       		popq	%rbp
  90              		.cfi_def_cfa 7, 8
  91 0072 C3       		ret
  92              		.cfi_endproc
  93              	.LFE7:
  95              		.globl	popcount_fast1
  97              	popcount_fast1:
  98              	.LFB8:
  36:popcount.c    **** 
  37:popcount.c    **** /*
  38:popcount.c    ****  * Clear 1-bit from the far right, one by one.
  39:popcount.c    ****  * Fast if there are less 1-bits.
  40:popcount.c    ****  */
  41:popcount.c    **** int popcount_fast1 (uint32_t n)
  42:popcount.c    **** {
  99              		.loc 1 42 1
 100              		.cfi_startproc
 101 0073 F30F1EFA 		endbr64
 102 0077 55       		pushq	%rbp
 103              		.cfi_def_cfa_offset 16
 104              		.cfi_offset 6, -16
 105 0078 4889E5   		movq	%rsp, %rbp
 106              		.cfi_def_cfa_register 6
 107 007b 897DEC   		movl	%edi, -20(%rbp)
  43:popcount.c    ****     int c = 0;
 108              		.loc 1 43 9
 109 007e C745FC00 		movl	$0, -4(%rbp)
 109      000000
  44:popcount.c    ****     while (n) {
 110              		.loc 1 44 11
 111 0085 EB0B     		jmp	.L11
 112              	.L12:
  45:popcount.c    ****         c++;
 113              		.loc 1 45 10
 114 0087 FF45FC   		incl	-4(%rbp)
  46:popcount.c    ****         n &= (n-1);
 115              		.loc 1 46 16
 116 008a 8B45EC   		movl	-20(%rbp), %eax
 117 008d FFC8     		decl	%eax
 118              		.loc 1 46 11
 119 008f 2145EC   		andl	%eax, -20(%rbp)
 120              	.L11:
  44:popcount.c    ****     while (n) {
 121              		.loc 1 44 11
 122 0092 837DEC00 		cmpl	$0, -20(%rbp)
 123 0096 75EF     		jne	.L12
  47:popcount.c    ****     }
  48:popcount.c    ****     return c;
 124              		.loc 1 48 12
 125 0098 8B45FC   		movl	-4(%rbp), %eax
  49:popcount.c    **** }
 126              		.loc 1 49 1
 127 009b 5D       		popq	%rbp
 128              		.cfi_def_cfa 7, 8
 129 009c C3       		ret
 130              		.cfi_endproc
 131              	.LFE8:
 133              		.globl	popcount_fast2
 135              	popcount_fast2:
 136              	.LFB9:
  50:popcount.c    **** 
  51:popcount.c    **** /*
  52:popcount.c    ****  * Set 0-bit from the far right, one by one.
  53:popcount.c    ****  * Fast if there are less 0-bits.
  54:popcount.c    ****  */
  55:popcount.c    **** int popcount_fast2 (uint32_t n)
  56:popcount.c    **** {
 137              		.loc 1 56 1
 138              		.cfi_startproc
 139 009d F30F1EFA 		endbr64
 140 00a1 55       		pushq	%rbp
 141              		.cfi_def_cfa_offset 16
 142              		.cfi_offset 6, -16
 143 00a2 4889E5   		movq	%rsp, %rbp
 144              		.cfi_def_cfa_register 6
 145 00a5 897DEC   		movl	%edi, -20(%rbp)
  57:popcount.c    ****     int c = 32;
 146              		.loc 1 57 9
 147 00a8 C745FC20 		movl	$32, -4(%rbp)
 147      000000
  58:popcount.c    ****     while (n != -1) {
 148              		.loc 1 58 11
 149 00af EB0B     		jmp	.L15
 150              	.L16:
  59:popcount.c    ****         c--;
 151              		.loc 1 59 10
 152 00b1 FF4DFC   		decl	-4(%rbp)
  60:popcount.c    ****         n |= (n+1);
 153              		.loc 1 60 16
 154 00b4 8B45EC   		movl	-20(%rbp), %eax
 155 00b7 FFC0     		incl	%eax
 156              		.loc 1 60 11
 157 00b9 0945EC   		orl	%eax, -20(%rbp)
 158              	.L15:
  58:popcount.c    ****     while (n != -1) {
 159              		.loc 1 58 11
 160 00bc 837DECFF 		cmpl	$-1, -20(%rbp)
 161 00c0 75EF     		jne	.L16
  61:popcount.c    ****     }
  62:popcount.c    ****     return c;
 162              		.loc 1 62 12
 163 00c2 8B45FC   		movl	-4(%rbp), %eax
  63:popcount.c    **** }
 164              		.loc 1 63 1
 165 00c5 5D       		popq	%rbp
 166              		.cfi_def_cfa 7, 8
 167 00c6 C3       		ret
 168              		.cfi_endproc
 169              	.LFE9:
 171              		.globl	popcount_fast1_unrolled
 173              	popcount_fast1_unrolled:
 174              	.LFB10:
  64:popcount.c    **** 
  65:popcount.c    **** /* If most bits are 0s, use the following unrolled solution.*/
  66:popcount.c    **** #define f(x) if ((n &= (n-1)) == 0) return x;
  67:popcount.c    **** int popcount_fast1_unrolled (uint32_t n)
  68:popcount.c    **** {
 175              		.loc 1 68 1
 176              		.cfi_startproc
 177 00c7 F30F1EFA 		endbr64
 178 00cb 55       		pushq	%rbp
 179              		.cfi_def_cfa_offset 16
 180              		.cfi_offset 6, -16
 181 00cc 4889E5   		movq	%rsp, %rbp
 182              		.cfi_def_cfa_register 6
 183 00cf 897DFC   		movl	%edi, -4(%rbp)
  69:popcount.c    ****     if (n == 0) return 0;
 184              		.loc 1 69 8
 185 00d2 837DFC00 		cmpl	$0, -4(%rbp)
 186 00d6 750A     		jne	.L19
 187              		.loc 1 69 24 discriminator 1
 188 00d8 B8000000 		movl	$0, %eax
 188      00
 189 00dd E9DB0200 		jmp	.L20
 189      00
 190              	.L19:
  70:popcount.c    ****     f( 1) f( 2) f( 3) f( 4) f( 5) f( 6) f( 7) f( 8)
 191              		.loc 1 70 5
 192 00e2 8B45FC   		movl	-4(%rbp), %eax
 193 00e5 FFC8     		decl	%eax
 194 00e7 2145FC   		andl	%eax, -4(%rbp)
 195 00ea 837DFC00 		cmpl	$0, -4(%rbp)
 196 00ee 750A     		jne	.L21
 197              		.loc 1 70 5 is_stmt 0 discriminator 1
 198 00f0 B8010000 		movl	$1, %eax
 198      00
 199 00f5 E9C30200 		jmp	.L20
 199      00
 200              	.L21:
 201              		.loc 1 70 11 is_stmt 1 discriminator 2
 202 00fa 8B45FC   		movl	-4(%rbp), %eax
 203 00fd FFC8     		decl	%eax
 204 00ff 2145FC   		andl	%eax, -4(%rbp)
 205 0102 837DFC00 		cmpl	$0, -4(%rbp)
 206 0106 750A     		jne	.L22
 207              		.loc 1 70 11 is_stmt 0 discriminator 3
 208 0108 B8020000 		movl	$2, %eax
 208      00
 209 010d E9AB0200 		jmp	.L20
 209      00
 210              	.L22:
 211              		.loc 1 70 17 is_stmt 1 discriminator 4
 212 0112 8B45FC   		movl	-4(%rbp), %eax
 213 0115 FFC8     		decl	%eax
 214 0117 2145FC   		andl	%eax, -4(%rbp)
 215 011a 837DFC00 		cmpl	$0, -4(%rbp)
 216 011e 750A     		jne	.L23
 217              		.loc 1 70 17 is_stmt 0 discriminator 5
 218 0120 B8030000 		movl	$3, %eax
 218      00
 219 0125 E9930200 		jmp	.L20
 219      00
 220              	.L23:
 221              		.loc 1 70 23 is_stmt 1 discriminator 6
 222 012a 8B45FC   		movl	-4(%rbp), %eax
 223 012d FFC8     		decl	%eax
 224 012f 2145FC   		andl	%eax, -4(%rbp)
 225 0132 837DFC00 		cmpl	$0, -4(%rbp)
 226 0136 750A     		jne	.L24
 227              		.loc 1 70 23 is_stmt 0 discriminator 7
 228 0138 B8040000 		movl	$4, %eax
 228      00
 229 013d E97B0200 		jmp	.L20
 229      00
 230              	.L24:
 231              		.loc 1 70 29 is_stmt 1 discriminator 8
 232 0142 8B45FC   		movl	-4(%rbp), %eax
 233 0145 FFC8     		decl	%eax
 234 0147 2145FC   		andl	%eax, -4(%rbp)
 235 014a 837DFC00 		cmpl	$0, -4(%rbp)
 236 014e 750A     		jne	.L25
 237              		.loc 1 70 29 is_stmt 0 discriminator 9
 238 0150 B8050000 		movl	$5, %eax
 238      00
 239 0155 E9630200 		jmp	.L20
 239      00
 240              	.L25:
 241              		.loc 1 70 35 is_stmt 1 discriminator 10
 242 015a 8B45FC   		movl	-4(%rbp), %eax
 243 015d FFC8     		decl	%eax
 244 015f 2145FC   		andl	%eax, -4(%rbp)
 245 0162 837DFC00 		cmpl	$0, -4(%rbp)
 246 0166 750A     		jne	.L26
 247              		.loc 1 70 35 is_stmt 0 discriminator 11
 248 0168 B8060000 		movl	$6, %eax
 248      00
 249 016d E94B0200 		jmp	.L20
 249      00
 250              	.L26:
 251              		.loc 1 70 41 is_stmt 1 discriminator 12
 252 0172 8B45FC   		movl	-4(%rbp), %eax
 253 0175 FFC8     		decl	%eax
 254 0177 2145FC   		andl	%eax, -4(%rbp)
 255 017a 837DFC00 		cmpl	$0, -4(%rbp)
 256 017e 750A     		jne	.L27
 257              		.loc 1 70 41 is_stmt 0 discriminator 13
 258 0180 B8070000 		movl	$7, %eax
 258      00
 259 0185 E9330200 		jmp	.L20
 259      00
 260              	.L27:
 261              		.loc 1 70 47 is_stmt 1 discriminator 14
 262 018a 8B45FC   		movl	-4(%rbp), %eax
 263 018d FFC8     		decl	%eax
 264 018f 2145FC   		andl	%eax, -4(%rbp)
 265 0192 837DFC00 		cmpl	$0, -4(%rbp)
 266 0196 750A     		jne	.L28
 267              		.loc 1 70 47 is_stmt 0 discriminator 15
 268 0198 B8080000 		movl	$8, %eax
 268      00
 269 019d E91B0200 		jmp	.L20
 269      00
 270              	.L28:
  71:popcount.c    ****     f( 9) f(10) f(11) f(12) f(13) f(14) f(15) f(16)
 271              		.loc 1 71 5 is_stmt 1
 272 01a2 8B45FC   		movl	-4(%rbp), %eax
 273 01a5 FFC8     		decl	%eax
 274 01a7 2145FC   		andl	%eax, -4(%rbp)
 275 01aa 837DFC00 		cmpl	$0, -4(%rbp)
 276 01ae 750A     		jne	.L29
 277              		.loc 1 71 5 is_stmt 0 discriminator 1
 278 01b0 B8090000 		movl	$9, %eax
 278      00
 279 01b5 E9030200 		jmp	.L20
 279      00
 280              	.L29:
 281              		.loc 1 71 11 is_stmt 1 discriminator 2
 282 01ba 8B45FC   		movl	-4(%rbp), %eax
 283 01bd FFC8     		decl	%eax
 284 01bf 2145FC   		andl	%eax, -4(%rbp)
 285 01c2 837DFC00 		cmpl	$0, -4(%rbp)
 286 01c6 750A     		jne	.L30
 287              		.loc 1 71 11 is_stmt 0 discriminator 3
 288 01c8 B80A0000 		movl	$10, %eax
 288      00
 289 01cd E9EB0100 		jmp	.L20
 289      00
 290              	.L30:
 291              		.loc 1 71 17 is_stmt 1 discriminator 4
 292 01d2 8B45FC   		movl	-4(%rbp), %eax
 293 01d5 FFC8     		decl	%eax
 294 01d7 2145FC   		andl	%eax, -4(%rbp)
 295 01da 837DFC00 		cmpl	$0, -4(%rbp)
 296 01de 750A     		jne	.L31
 297              		.loc 1 71 17 is_stmt 0 discriminator 5
 298 01e0 B80B0000 		movl	$11, %eax
 298      00
 299 01e5 E9D30100 		jmp	.L20
 299      00
 300              	.L31:
 301              		.loc 1 71 23 is_stmt 1 discriminator 6
 302 01ea 8B45FC   		movl	-4(%rbp), %eax
 303 01ed FFC8     		decl	%eax
 304 01ef 2145FC   		andl	%eax, -4(%rbp)
 305 01f2 837DFC00 		cmpl	$0, -4(%rbp)
 306 01f6 750A     		jne	.L32
 307              		.loc 1 71 23 is_stmt 0 discriminator 7
 308 01f8 B80C0000 		movl	$12, %eax
 308      00
 309 01fd E9BB0100 		jmp	.L20
 309      00
 310              	.L32:
 311              		.loc 1 71 29 is_stmt 1 discriminator 8
 312 0202 8B45FC   		movl	-4(%rbp), %eax
 313 0205 FFC8     		decl	%eax
 314 0207 2145FC   		andl	%eax, -4(%rbp)
 315 020a 837DFC00 		cmpl	$0, -4(%rbp)
 316 020e 750A     		jne	.L33
 317              		.loc 1 71 29 is_stmt 0 discriminator 9
 318 0210 B80D0000 		movl	$13, %eax
 318      00
 319 0215 E9A30100 		jmp	.L20
 319      00
 320              	.L33:
 321              		.loc 1 71 35 is_stmt 1 discriminator 10
 322 021a 8B45FC   		movl	-4(%rbp), %eax
 323 021d FFC8     		decl	%eax
 324 021f 2145FC   		andl	%eax, -4(%rbp)
 325 0222 837DFC00 		cmpl	$0, -4(%rbp)
 326 0226 750A     		jne	.L34
 327              		.loc 1 71 35 is_stmt 0 discriminator 11
 328 0228 B80E0000 		movl	$14, %eax
 328      00
 329 022d E98B0100 		jmp	.L20
 329      00
 330              	.L34:
 331              		.loc 1 71 41 is_stmt 1 discriminator 12
 332 0232 8B45FC   		movl	-4(%rbp), %eax
 333 0235 FFC8     		decl	%eax
 334 0237 2145FC   		andl	%eax, -4(%rbp)
 335 023a 837DFC00 		cmpl	$0, -4(%rbp)
 336 023e 750A     		jne	.L35
 337              		.loc 1 71 41 is_stmt 0 discriminator 13
 338 0240 B80F0000 		movl	$15, %eax
 338      00
 339 0245 E9730100 		jmp	.L20
 339      00
 340              	.L35:
 341              		.loc 1 71 47 is_stmt 1 discriminator 14
 342 024a 8B45FC   		movl	-4(%rbp), %eax
 343 024d FFC8     		decl	%eax
 344 024f 2145FC   		andl	%eax, -4(%rbp)
 345 0252 837DFC00 		cmpl	$0, -4(%rbp)
 346 0256 750A     		jne	.L36
 347              		.loc 1 71 47 is_stmt 0 discriminator 15
 348 0258 B8100000 		movl	$16, %eax
 348      00
 349 025d E95B0100 		jmp	.L20
 349      00
 350              	.L36:
  72:popcount.c    ****     f(17) f(18) f(19) f(20) f(21) f(22) f(23) f(24)
 351              		.loc 1 72 5 is_stmt 1
 352 0262 8B45FC   		movl	-4(%rbp), %eax
 353 0265 FFC8     		decl	%eax
 354 0267 2145FC   		andl	%eax, -4(%rbp)
 355 026a 837DFC00 		cmpl	$0, -4(%rbp)
 356 026e 750A     		jne	.L37
 357              		.loc 1 72 5 is_stmt 0 discriminator 1
 358 0270 B8110000 		movl	$17, %eax
 358      00
 359 0275 E9430100 		jmp	.L20
 359      00
 360              	.L37:
 361              		.loc 1 72 11 is_stmt 1 discriminator 2
 362 027a 8B45FC   		movl	-4(%rbp), %eax
 363 027d FFC8     		decl	%eax
 364 027f 2145FC   		andl	%eax, -4(%rbp)
 365 0282 837DFC00 		cmpl	$0, -4(%rbp)
 366 0286 750A     		jne	.L38
 367              		.loc 1 72 11 is_stmt 0 discriminator 3
 368 0288 B8120000 		movl	$18, %eax
 368      00
 369 028d E92B0100 		jmp	.L20
 369      00
 370              	.L38:
 371              		.loc 1 72 17 is_stmt 1 discriminator 4
 372 0292 8B45FC   		movl	-4(%rbp), %eax
 373 0295 FFC8     		decl	%eax
 374 0297 2145FC   		andl	%eax, -4(%rbp)
 375 029a 837DFC00 		cmpl	$0, -4(%rbp)
 376 029e 750A     		jne	.L39
 377              		.loc 1 72 17 is_stmt 0 discriminator 5
 378 02a0 B8130000 		movl	$19, %eax
 378      00
 379 02a5 E9130100 		jmp	.L20
 379      00
 380              	.L39:
 381              		.loc 1 72 23 is_stmt 1 discriminator 6
 382 02aa 8B45FC   		movl	-4(%rbp), %eax
 383 02ad FFC8     		decl	%eax
 384 02af 2145FC   		andl	%eax, -4(%rbp)
 385 02b2 837DFC00 		cmpl	$0, -4(%rbp)
 386 02b6 750A     		jne	.L40
 387              		.loc 1 72 23 is_stmt 0 discriminator 7
 388 02b8 B8140000 		movl	$20, %eax
 388      00
 389 02bd E9FB0000 		jmp	.L20
 389      00
 390              	.L40:
 391              		.loc 1 72 29 is_stmt 1 discriminator 8
 392 02c2 8B45FC   		movl	-4(%rbp), %eax
 393 02c5 FFC8     		decl	%eax
 394 02c7 2145FC   		andl	%eax, -4(%rbp)
 395 02ca 837DFC00 		cmpl	$0, -4(%rbp)
 396 02ce 750A     		jne	.L41
 397              		.loc 1 72 29 is_stmt 0 discriminator 9
 398 02d0 B8150000 		movl	$21, %eax
 398      00
 399 02d5 E9E30000 		jmp	.L20
 399      00
 400              	.L41:
 401              		.loc 1 72 35 is_stmt 1 discriminator 10
 402 02da 8B45FC   		movl	-4(%rbp), %eax
 403 02dd FFC8     		decl	%eax
 404 02df 2145FC   		andl	%eax, -4(%rbp)
 405 02e2 837DFC00 		cmpl	$0, -4(%rbp)
 406 02e6 750A     		jne	.L42
 407              		.loc 1 72 35 is_stmt 0 discriminator 11
 408 02e8 B8160000 		movl	$22, %eax
 408      00
 409 02ed E9CB0000 		jmp	.L20
 409      00
 410              	.L42:
 411              		.loc 1 72 41 is_stmt 1 discriminator 12
 412 02f2 8B45FC   		movl	-4(%rbp), %eax
 413 02f5 FFC8     		decl	%eax
 414 02f7 2145FC   		andl	%eax, -4(%rbp)
 415 02fa 837DFC00 		cmpl	$0, -4(%rbp)
 416 02fe 750A     		jne	.L43
 417              		.loc 1 72 41 is_stmt 0 discriminator 13
 418 0300 B8170000 		movl	$23, %eax
 418      00
 419 0305 E9B30000 		jmp	.L20
 419      00
 420              	.L43:
 421              		.loc 1 72 47 is_stmt 1 discriminator 14
 422 030a 8B45FC   		movl	-4(%rbp), %eax
 423 030d FFC8     		decl	%eax
 424 030f 2145FC   		andl	%eax, -4(%rbp)
 425 0312 837DFC00 		cmpl	$0, -4(%rbp)
 426 0316 750A     		jne	.L44
 427              		.loc 1 72 47 is_stmt 0 discriminator 15
 428 0318 B8180000 		movl	$24, %eax
 428      00
 429 031d E99B0000 		jmp	.L20
 429      00
 430              	.L44:
  73:popcount.c    ****     f(25) f(26) f(27) f(24) f(29) f(30) f(31)
 431              		.loc 1 73 5 is_stmt 1
 432 0322 8B45FC   		movl	-4(%rbp), %eax
 433 0325 FFC8     		decl	%eax
 434 0327 2145FC   		andl	%eax, -4(%rbp)
 435 032a 837DFC00 		cmpl	$0, -4(%rbp)
 436 032e 750A     		jne	.L45
 437              		.loc 1 73 5 is_stmt 0 discriminator 1
 438 0330 B8190000 		movl	$25, %eax
 438      00
 439 0335 E9830000 		jmp	.L20
 439      00
 440              	.L45:
 441              		.loc 1 73 11 is_stmt 1 discriminator 2
 442 033a 8B45FC   		movl	-4(%rbp), %eax
 443 033d FFC8     		decl	%eax
 444 033f 2145FC   		andl	%eax, -4(%rbp)
 445 0342 837DFC00 		cmpl	$0, -4(%rbp)
 446 0346 7507     		jne	.L46
 447              		.loc 1 73 11 is_stmt 0 discriminator 3
 448 0348 B81A0000 		movl	$26, %eax
 448      00
 449 034d EB6E     		jmp	.L20
 450              	.L46:
 451              		.loc 1 73 17 is_stmt 1 discriminator 4
 452 034f 8B45FC   		movl	-4(%rbp), %eax
 453 0352 FFC8     		decl	%eax
 454 0354 2145FC   		andl	%eax, -4(%rbp)
 455 0357 837DFC00 		cmpl	$0, -4(%rbp)
 456 035b 7507     		jne	.L47
 457              		.loc 1 73 17 is_stmt 0 discriminator 5
 458 035d B81B0000 		movl	$27, %eax
 458      00
 459 0362 EB59     		jmp	.L20
 460              	.L47:
 461              		.loc 1 73 23 is_stmt 1 discriminator 6
 462 0364 8B45FC   		movl	-4(%rbp), %eax
 463 0367 FFC8     		decl	%eax
 464 0369 2145FC   		andl	%eax, -4(%rbp)
 465 036c 837DFC00 		cmpl	$0, -4(%rbp)
 466 0370 7507     		jne	.L48
 467              		.loc 1 73 23 is_stmt 0 discriminator 7
 468 0372 B8180000 		movl	$24, %eax
 468      00
 469 0377 EB44     		jmp	.L20
 470              	.L48:
 471              		.loc 1 73 29 is_stmt 1 discriminator 8
 472 0379 8B45FC   		movl	-4(%rbp), %eax
 473 037c FFC8     		decl	%eax
 474 037e 2145FC   		andl	%eax, -4(%rbp)
 475 0381 837DFC00 		cmpl	$0, -4(%rbp)
 476 0385 7507     		jne	.L49
 477              		.loc 1 73 29 is_stmt 0 discriminator 9
 478 0387 B81D0000 		movl	$29, %eax
 478      00
 479 038c EB2F     		jmp	.L20
 480              	.L49:
 481              		.loc 1 73 35 is_stmt 1 discriminator 10
 482 038e 8B45FC   		movl	-4(%rbp), %eax
 483 0391 FFC8     		decl	%eax
 484 0393 2145FC   		andl	%eax, -4(%rbp)
 485 0396 837DFC00 		cmpl	$0, -4(%rbp)
 486 039a 7507     		jne	.L50
 487              		.loc 1 73 35 is_stmt 0 discriminator 11
 488 039c B81E0000 		movl	$30, %eax
 488      00
 489 03a1 EB1A     		jmp	.L20
 490              	.L50:
 491              		.loc 1 73 41 is_stmt 1 discriminator 12
 492 03a3 8B45FC   		movl	-4(%rbp), %eax
 493 03a6 FFC8     		decl	%eax
 494 03a8 2145FC   		andl	%eax, -4(%rbp)
 495 03ab 837DFC00 		cmpl	$0, -4(%rbp)
 496 03af 7507     		jne	.L51
 497              		.loc 1 73 41 is_stmt 0 discriminator 13
 498 03b1 B81F0000 		movl	$31, %eax
 498      00
 499 03b6 EB05     		jmp	.L20
 500              	.L51:
  74:popcount.c    ****     return 32;
 501              		.loc 1 74 12 is_stmt 1
 502 03b8 B8200000 		movl	$32, %eax
 502      00
 503              	.L20:
  75:popcount.c    **** }
 504              		.loc 1 75 1
 505 03bd 5D       		popq	%rbp
 506              		.cfi_def_cfa 7, 8
 507 03be C3       		ret
 508              		.cfi_endproc
 509              	.LFE10:
 511              		.globl	popcount_fast2_unrolled
 513              	popcount_fast2_unrolled:
 514              	.LFB11:
  76:popcount.c    **** 
  77:popcount.c    **** /* If most bits are 1s, use the following unrolled solution.*/
  78:popcount.c    **** #define g(x) if ((n |= (n+1)) == -1) return 32-x;
  79:popcount.c    **** int popcount_fast2_unrolled (uint32_t n)
  80:popcount.c    **** {
 515              		.loc 1 80 1
 516              		.cfi_startproc
 517 03bf F30F1EFA 		endbr64
 518 03c3 55       		pushq	%rbp
 519              		.cfi_def_cfa_offset 16
 520              		.cfi_offset 6, -16
 521 03c4 4889E5   		movq	%rsp, %rbp
 522              		.cfi_def_cfa_register 6
 523 03c7 897DFC   		movl	%edi, -4(%rbp)
  81:popcount.c    ****     if (n == -1) return 32;
 524              		.loc 1 81 8
 525 03ca 837DFCFF 		cmpl	$-1, -4(%rbp)
 526 03ce 750A     		jne	.L53
 527              		.loc 1 81 25 discriminator 1
 528 03d0 B8200000 		movl	$32, %eax
 528      00
 529 03d5 E9DB0200 		jmp	.L54
 529      00
 530              	.L53:
  82:popcount.c    ****     g( 1) g( 2) g( 3) g( 4) g( 5) g( 6) g( 7) g( 8)
 531              		.loc 1 82 5
 532 03da 8B45FC   		movl	-4(%rbp), %eax
 533 03dd FFC0     		incl	%eax
 534 03df 0945FC   		orl	%eax, -4(%rbp)
 535 03e2 837DFCFF 		cmpl	$-1, -4(%rbp)
 536 03e6 750A     		jne	.L55
 537              		.loc 1 82 5 is_stmt 0 discriminator 1
 538 03e8 B81F0000 		movl	$31, %eax
 538      00
 539 03ed E9C30200 		jmp	.L54
 539      00
 540              	.L55:
 541              		.loc 1 82 11 is_stmt 1 discriminator 2
 542 03f2 8B45FC   		movl	-4(%rbp), %eax
 543 03f5 FFC0     		incl	%eax
 544 03f7 0945FC   		orl	%eax, -4(%rbp)
 545 03fa 837DFCFF 		cmpl	$-1, -4(%rbp)
 546 03fe 750A     		jne	.L56
 547              		.loc 1 82 11 is_stmt 0 discriminator 3
 548 0400 B81E0000 		movl	$30, %eax
 548      00
 549 0405 E9AB0200 		jmp	.L54
 549      00
 550              	.L56:
 551              		.loc 1 82 17 is_stmt 1 discriminator 4
 552 040a 8B45FC   		movl	-4(%rbp), %eax
 553 040d FFC0     		incl	%eax
 554 040f 0945FC   		orl	%eax, -4(%rbp)
 555 0412 837DFCFF 		cmpl	$-1, -4(%rbp)
 556 0416 750A     		jne	.L57
 557              		.loc 1 82 17 is_stmt 0 discriminator 5
 558 0418 B81D0000 		movl	$29, %eax
 558      00
 559 041d E9930200 		jmp	.L54
 559      00
 560              	.L57:
 561              		.loc 1 82 23 is_stmt 1 discriminator 6
 562 0422 8B45FC   		movl	-4(%rbp), %eax
 563 0425 FFC0     		incl	%eax
 564 0427 0945FC   		orl	%eax, -4(%rbp)
 565 042a 837DFCFF 		cmpl	$-1, -4(%rbp)
 566 042e 750A     		jne	.L58
 567              		.loc 1 82 23 is_stmt 0 discriminator 7
 568 0430 B81C0000 		movl	$28, %eax
 568      00
 569 0435 E97B0200 		jmp	.L54
 569      00
 570              	.L58:
 571              		.loc 1 82 29 is_stmt 1 discriminator 8
 572 043a 8B45FC   		movl	-4(%rbp), %eax
 573 043d FFC0     		incl	%eax
 574 043f 0945FC   		orl	%eax, -4(%rbp)
 575 0442 837DFCFF 		cmpl	$-1, -4(%rbp)
 576 0446 750A     		jne	.L59
 577              		.loc 1 82 29 is_stmt 0 discriminator 9
 578 0448 B81B0000 		movl	$27, %eax
 578      00
 579 044d E9630200 		jmp	.L54
 579      00
 580              	.L59:
 581              		.loc 1 82 35 is_stmt 1 discriminator 10
 582 0452 8B45FC   		movl	-4(%rbp), %eax
 583 0455 FFC0     		incl	%eax
 584 0457 0945FC   		orl	%eax, -4(%rbp)
 585 045a 837DFCFF 		cmpl	$-1, -4(%rbp)
 586 045e 750A     		jne	.L60
 587              		.loc 1 82 35 is_stmt 0 discriminator 11
 588 0460 B81A0000 		movl	$26, %eax
 588      00
 589 0465 E94B0200 		jmp	.L54
 589      00
 590              	.L60:
 591              		.loc 1 82 41 is_stmt 1 discriminator 12
 592 046a 8B45FC   		movl	-4(%rbp), %eax
 593 046d FFC0     		incl	%eax
 594 046f 0945FC   		orl	%eax, -4(%rbp)
 595 0472 837DFCFF 		cmpl	$-1, -4(%rbp)
 596 0476 750A     		jne	.L61
 597              		.loc 1 82 41 is_stmt 0 discriminator 13
 598 0478 B8190000 		movl	$25, %eax
 598      00
 599 047d E9330200 		jmp	.L54
 599      00
 600              	.L61:
 601              		.loc 1 82 47 is_stmt 1 discriminator 14
 602 0482 8B45FC   		movl	-4(%rbp), %eax
 603 0485 FFC0     		incl	%eax
 604 0487 0945FC   		orl	%eax, -4(%rbp)
 605 048a 837DFCFF 		cmpl	$-1, -4(%rbp)
 606 048e 750A     		jne	.L62
 607              		.loc 1 82 47 is_stmt 0 discriminator 15
 608 0490 B8180000 		movl	$24, %eax
 608      00
 609 0495 E91B0200 		jmp	.L54
 609      00
 610              	.L62:
  83:popcount.c    ****     g( 9) g(10) g(11) g(12) g(13) g(14) g(15) g(16)
 611              		.loc 1 83 5 is_stmt 1
 612 049a 8B45FC   		movl	-4(%rbp), %eax
 613 049d FFC0     		incl	%eax
 614 049f 0945FC   		orl	%eax, -4(%rbp)
 615 04a2 837DFCFF 		cmpl	$-1, -4(%rbp)
 616 04a6 750A     		jne	.L63
 617              		.loc 1 83 5 is_stmt 0 discriminator 1
 618 04a8 B8170000 		movl	$23, %eax
 618      00
 619 04ad E9030200 		jmp	.L54
 619      00
 620              	.L63:
 621              		.loc 1 83 11 is_stmt 1 discriminator 2
 622 04b2 8B45FC   		movl	-4(%rbp), %eax
 623 04b5 FFC0     		incl	%eax
 624 04b7 0945FC   		orl	%eax, -4(%rbp)
 625 04ba 837DFCFF 		cmpl	$-1, -4(%rbp)
 626 04be 750A     		jne	.L64
 627              		.loc 1 83 11 is_stmt 0 discriminator 3
 628 04c0 B8160000 		movl	$22, %eax
 628      00
 629 04c5 E9EB0100 		jmp	.L54
 629      00
 630              	.L64:
 631              		.loc 1 83 17 is_stmt 1 discriminator 4
 632 04ca 8B45FC   		movl	-4(%rbp), %eax
 633 04cd FFC0     		incl	%eax
 634 04cf 0945FC   		orl	%eax, -4(%rbp)
 635 04d2 837DFCFF 		cmpl	$-1, -4(%rbp)
 636 04d6 750A     		jne	.L65
 637              		.loc 1 83 17 is_stmt 0 discriminator 5
 638 04d8 B8150000 		movl	$21, %eax
 638      00
 639 04dd E9D30100 		jmp	.L54
 639      00
 640              	.L65:
 641              		.loc 1 83 23 is_stmt 1 discriminator 6
 642 04e2 8B45FC   		movl	-4(%rbp), %eax
 643 04e5 FFC0     		incl	%eax
 644 04e7 0945FC   		orl	%eax, -4(%rbp)
 645 04ea 837DFCFF 		cmpl	$-1, -4(%rbp)
 646 04ee 750A     		jne	.L66
 647              		.loc 1 83 23 is_stmt 0 discriminator 7
 648 04f0 B8140000 		movl	$20, %eax
 648      00
 649 04f5 E9BB0100 		jmp	.L54
 649      00
 650              	.L66:
 651              		.loc 1 83 29 is_stmt 1 discriminator 8
 652 04fa 8B45FC   		movl	-4(%rbp), %eax
 653 04fd FFC0     		incl	%eax
 654 04ff 0945FC   		orl	%eax, -4(%rbp)
 655 0502 837DFCFF 		cmpl	$-1, -4(%rbp)
 656 0506 750A     		jne	.L67
 657              		.loc 1 83 29 is_stmt 0 discriminator 9
 658 0508 B8130000 		movl	$19, %eax
 658      00
 659 050d E9A30100 		jmp	.L54
 659      00
 660              	.L67:
 661              		.loc 1 83 35 is_stmt 1 discriminator 10
 662 0512 8B45FC   		movl	-4(%rbp), %eax
 663 0515 FFC0     		incl	%eax
 664 0517 0945FC   		orl	%eax, -4(%rbp)
 665 051a 837DFCFF 		cmpl	$-1, -4(%rbp)
 666 051e 750A     		jne	.L68
 667              		.loc 1 83 35 is_stmt 0 discriminator 11
 668 0520 B8120000 		movl	$18, %eax
 668      00
 669 0525 E98B0100 		jmp	.L54
 669      00
 670              	.L68:
 671              		.loc 1 83 41 is_stmt 1 discriminator 12
 672 052a 8B45FC   		movl	-4(%rbp), %eax
 673 052d FFC0     		incl	%eax
 674 052f 0945FC   		orl	%eax, -4(%rbp)
 675 0532 837DFCFF 		cmpl	$-1, -4(%rbp)
 676 0536 750A     		jne	.L69
 677              		.loc 1 83 41 is_stmt 0 discriminator 13
 678 0538 B8110000 		movl	$17, %eax
 678      00
 679 053d E9730100 		jmp	.L54
 679      00
 680              	.L69:
 681              		.loc 1 83 47 is_stmt 1 discriminator 14
 682 0542 8B45FC   		movl	-4(%rbp), %eax
 683 0545 FFC0     		incl	%eax
 684 0547 0945FC   		orl	%eax, -4(%rbp)
 685 054a 837DFCFF 		cmpl	$-1, -4(%rbp)
 686 054e 750A     		jne	.L70
 687              		.loc 1 83 47 is_stmt 0 discriminator 15
 688 0550 B8100000 		movl	$16, %eax
 688      00
 689 0555 E95B0100 		jmp	.L54
 689      00
 690              	.L70:
  84:popcount.c    ****     g(17) g(18) g(19) g(20) g(21) g(22) g(23) g(24)
 691              		.loc 1 84 5 is_stmt 1
 692 055a 8B45FC   		movl	-4(%rbp), %eax
 693 055d FFC0     		incl	%eax
 694 055f 0945FC   		orl	%eax, -4(%rbp)
 695 0562 837DFCFF 		cmpl	$-1, -4(%rbp)
 696 0566 750A     		jne	.L71
 697              		.loc 1 84 5 is_stmt 0 discriminator 1
 698 0568 B80F0000 		movl	$15, %eax
 698      00
 699 056d E9430100 		jmp	.L54
 699      00
 700              	.L71:
 701              		.loc 1 84 11 is_stmt 1 discriminator 2
 702 0572 8B45FC   		movl	-4(%rbp), %eax
 703 0575 FFC0     		incl	%eax
 704 0577 0945FC   		orl	%eax, -4(%rbp)
 705 057a 837DFCFF 		cmpl	$-1, -4(%rbp)
 706 057e 750A     		jne	.L72
 707              		.loc 1 84 11 is_stmt 0 discriminator 3
 708 0580 B80E0000 		movl	$14, %eax
 708      00
 709 0585 E92B0100 		jmp	.L54
 709      00
 710              	.L72:
 711              		.loc 1 84 17 is_stmt 1 discriminator 4
 712 058a 8B45FC   		movl	-4(%rbp), %eax
 713 058d FFC0     		incl	%eax
 714 058f 0945FC   		orl	%eax, -4(%rbp)
 715 0592 837DFCFF 		cmpl	$-1, -4(%rbp)
 716 0596 750A     		jne	.L73
 717              		.loc 1 84 17 is_stmt 0 discriminator 5
 718 0598 B80D0000 		movl	$13, %eax
 718      00
 719 059d E9130100 		jmp	.L54
 719      00
 720              	.L73:
 721              		.loc 1 84 23 is_stmt 1 discriminator 6
 722 05a2 8B45FC   		movl	-4(%rbp), %eax
 723 05a5 FFC0     		incl	%eax
 724 05a7 0945FC   		orl	%eax, -4(%rbp)
 725 05aa 837DFCFF 		cmpl	$-1, -4(%rbp)
 726 05ae 750A     		jne	.L74
 727              		.loc 1 84 23 is_stmt 0 discriminator 7
 728 05b0 B80C0000 		movl	$12, %eax
 728      00
 729 05b5 E9FB0000 		jmp	.L54
 729      00
 730              	.L74:
 731              		.loc 1 84 29 is_stmt 1 discriminator 8
 732 05ba 8B45FC   		movl	-4(%rbp), %eax
 733 05bd FFC0     		incl	%eax
 734 05bf 0945FC   		orl	%eax, -4(%rbp)
 735 05c2 837DFCFF 		cmpl	$-1, -4(%rbp)
 736 05c6 750A     		jne	.L75
 737              		.loc 1 84 29 is_stmt 0 discriminator 9
 738 05c8 B80B0000 		movl	$11, %eax
 738      00
 739 05cd E9E30000 		jmp	.L54
 739      00
 740              	.L75:
 741              		.loc 1 84 35 is_stmt 1 discriminator 10
 742 05d2 8B45FC   		movl	-4(%rbp), %eax
 743 05d5 FFC0     		incl	%eax
 744 05d7 0945FC   		orl	%eax, -4(%rbp)
 745 05da 837DFCFF 		cmpl	$-1, -4(%rbp)
 746 05de 750A     		jne	.L76
 747              		.loc 1 84 35 is_stmt 0 discriminator 11
 748 05e0 B80A0000 		movl	$10, %eax
 748      00
 749 05e5 E9CB0000 		jmp	.L54
 749      00
 750              	.L76:
 751              		.loc 1 84 41 is_stmt 1 discriminator 12
 752 05ea 8B45FC   		movl	-4(%rbp), %eax
 753 05ed FFC0     		incl	%eax
 754 05ef 0945FC   		orl	%eax, -4(%rbp)
 755 05f2 837DFCFF 		cmpl	$-1, -4(%rbp)
 756 05f6 750A     		jne	.L77
 757              		.loc 1 84 41 is_stmt 0 discriminator 13
 758 05f8 B8090000 		movl	$9, %eax
 758      00
 759 05fd E9B30000 		jmp	.L54
 759      00
 760              	.L77:
 761              		.loc 1 84 47 is_stmt 1 discriminator 14
 762 0602 8B45FC   		movl	-4(%rbp), %eax
 763 0605 FFC0     		incl	%eax
 764 0607 0945FC   		orl	%eax, -4(%rbp)
 765 060a 837DFCFF 		cmpl	$-1, -4(%rbp)
 766 060e 750A     		jne	.L78
 767              		.loc 1 84 47 is_stmt 0 discriminator 15
 768 0610 B8080000 		movl	$8, %eax
 768      00
 769 0615 E99B0000 		jmp	.L54
 769      00
 770              	.L78:
  85:popcount.c    ****     g(25) g(26) g(27) g(24) g(29) g(30) g(31)
 771              		.loc 1 85 5 is_stmt 1
 772 061a 8B45FC   		movl	-4(%rbp), %eax
 773 061d FFC0     		incl	%eax
 774 061f 0945FC   		orl	%eax, -4(%rbp)
 775 0622 837DFCFF 		cmpl	$-1, -4(%rbp)
 776 0626 750A     		jne	.L79
 777              		.loc 1 85 5 is_stmt 0 discriminator 1
 778 0628 B8070000 		movl	$7, %eax
 778      00
 779 062d E9830000 		jmp	.L54
 779      00
 780              	.L79:
 781              		.loc 1 85 11 is_stmt 1 discriminator 2
 782 0632 8B45FC   		movl	-4(%rbp), %eax
 783 0635 FFC0     		incl	%eax
 784 0637 0945FC   		orl	%eax, -4(%rbp)
 785 063a 837DFCFF 		cmpl	$-1, -4(%rbp)
 786 063e 7507     		jne	.L80
 787              		.loc 1 85 11 is_stmt 0 discriminator 3
 788 0640 B8060000 		movl	$6, %eax
 788      00
 789 0645 EB6E     		jmp	.L54
 790              	.L80:
 791              		.loc 1 85 17 is_stmt 1 discriminator 4
 792 0647 8B45FC   		movl	-4(%rbp), %eax
 793 064a FFC0     		incl	%eax
 794 064c 0945FC   		orl	%eax, -4(%rbp)
 795 064f 837DFCFF 		cmpl	$-1, -4(%rbp)
 796 0653 7507     		jne	.L81
 797              		.loc 1 85 17 is_stmt 0 discriminator 5
 798 0655 B8050000 		movl	$5, %eax
 798      00
 799 065a EB59     		jmp	.L54
 800              	.L81:
 801              		.loc 1 85 23 is_stmt 1 discriminator 6
 802 065c 8B45FC   		movl	-4(%rbp), %eax
 803 065f FFC0     		incl	%eax
 804 0661 0945FC   		orl	%eax, -4(%rbp)
 805 0664 837DFCFF 		cmpl	$-1, -4(%rbp)
 806 0668 7507     		jne	.L82
 807              		.loc 1 85 23 is_stmt 0 discriminator 7
 808 066a B8080000 		movl	$8, %eax
 808      00
 809 066f EB44     		jmp	.L54
 810              	.L82:
 811              		.loc 1 85 29 is_stmt 1 discriminator 8
 812 0671 8B45FC   		movl	-4(%rbp), %eax
 813 0674 FFC0     		incl	%eax
 814 0676 0945FC   		orl	%eax, -4(%rbp)
 815 0679 837DFCFF 		cmpl	$-1, -4(%rbp)
 816 067d 7507     		jne	.L83
 817              		.loc 1 85 29 is_stmt 0 discriminator 9
 818 067f B8030000 		movl	$3, %eax
 818      00
 819 0684 EB2F     		jmp	.L54
 820              	.L83:
 821              		.loc 1 85 35 is_stmt 1 discriminator 10
 822 0686 8B45FC   		movl	-4(%rbp), %eax
 823 0689 FFC0     		incl	%eax
 824 068b 0945FC   		orl	%eax, -4(%rbp)
 825 068e 837DFCFF 		cmpl	$-1, -4(%rbp)
 826 0692 7507     		jne	.L84
 827              		.loc 1 85 35 is_stmt 0 discriminator 11
 828 0694 B8020000 		movl	$2, %eax
 828      00
 829 0699 EB1A     		jmp	.L54
 830              	.L84:
 831              		.loc 1 85 41 is_stmt 1 discriminator 12
 832 069b 8B45FC   		movl	-4(%rbp), %eax
 833 069e FFC0     		incl	%eax
 834 06a0 0945FC   		orl	%eax, -4(%rbp)
 835 06a3 837DFCFF 		cmpl	$-1, -4(%rbp)
 836 06a7 7507     		jne	.L85
 837              		.loc 1 85 41 is_stmt 0 discriminator 13
 838 06a9 B8010000 		movl	$1, %eax
 838      00
 839 06ae EB05     		jmp	.L54
 840              	.L85:
  86:popcount.c    ****     return 0;
 841              		.loc 1 86 12 is_stmt 1
 842 06b0 B8000000 		movl	$0, %eax
 842      00
 843              	.L54:
  87:popcount.c    **** }
 844              		.loc 1 87 1
 845 06b5 5D       		popq	%rbp
 846              		.cfi_def_cfa 7, 8
 847 06b6 C3       		ret
 848              		.cfi_endproc
 849              	.LFE11:
 851              		.globl	popcount_dnq1
 853              	popcount_dnq1:
 854              	.LFB12:
  88:popcount.c    **** 
  89:popcount.c    **** /*
  90:popcount.c    ****  * Note the precedence of (+/-, >>, &) in such order,
  91:popcount.c    ****  * so all '(' and ')' are mandatory in the code below!
  92:popcount.c    ****  */
  93:popcount.c    **** 
  94:popcount.c    **** /* Divide-and-Conquer - original (20 arithmetic operations) */
  95:popcount.c    **** int popcount_dnq1 (uint32_t n)
  96:popcount.c    **** {
 855              		.loc 1 96 1
 856              		.cfi_startproc
 857 06b7 F30F1EFA 		endbr64
 858 06bb 55       		pushq	%rbp
 859              		.cfi_def_cfa_offset 16
 860              		.cfi_offset 6, -16
 861 06bc 4889E5   		movq	%rsp, %rbp
 862              		.cfi_def_cfa_register 6
 863 06bf 897DFC   		movl	%edi, -4(%rbp)
  97:popcount.c    ****     n = (n & 0x55555555) + ((n >> 1) & 0x55555555);
 864              		.loc 1 97 12
 865 06c2 8B45FC   		movl	-4(%rbp), %eax
 866 06c5 25555555 		andl	$1431655765, %eax
 866      55
 867 06ca 89C2     		movl	%eax, %edx
 868              		.loc 1 97 32
 869 06cc 8B45FC   		movl	-4(%rbp), %eax
 870 06cf D1E8     		shrl	%eax
 871              		.loc 1 97 38
 872 06d1 25555555 		andl	$1431655765, %eax
 872      55
 873              		.loc 1 97 7
 874 06d6 01D0     		addl	%edx, %eax
 875 06d8 8945FC   		movl	%eax, -4(%rbp)
  98:popcount.c    ****     n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
 876              		.loc 1 98 12
 877 06db 8B45FC   		movl	-4(%rbp), %eax
 878 06de 25333333 		andl	$858993459, %eax
 878      33
 879 06e3 89C2     		movl	%eax, %edx
 880              		.loc 1 98 32
 881 06e5 8B45FC   		movl	-4(%rbp), %eax
 882 06e8 C1E802   		shrl	$2, %eax
 883              		.loc 1 98 38
 884 06eb 25333333 		andl	$858993459, %eax
 884      33
 885              		.loc 1 98 7
 886 06f0 01D0     		addl	%edx, %eax
 887 06f2 8945FC   		movl	%eax, -4(%rbp)
  99:popcount.c    ****     n = (n & 0x0F0F0F0F) + ((n >> 4) & 0x0F0F0F0F);
 888              		.loc 1 99 12
 889 06f5 8B45FC   		movl	-4(%rbp), %eax
 890 06f8 250F0F0F 		andl	$252645135, %eax
 890      0F
 891 06fd 89C2     		movl	%eax, %edx
 892              		.loc 1 99 32
 893 06ff 8B45FC   		movl	-4(%rbp), %eax
 894 0702 C1E804   		shrl	$4, %eax
 895              		.loc 1 99 38
 896 0705 250F0F0F 		andl	$252645135, %eax
 896      0F
 897              		.loc 1 99 7
 898 070a 01D0     		addl	%edx, %eax
 899 070c 8945FC   		movl	%eax, -4(%rbp)
 100:popcount.c    ****     n = (n & 0x00FF00FF) + ((n >> 8) & 0x00FF00FF);
 900              		.loc 1 100 12
 901 070f 8B45FC   		movl	-4(%rbp), %eax
 902 0712 25FF00FF 		andl	$16711935, %eax
 902      00
 903 0717 89C2     		movl	%eax, %edx
 904              		.loc 1 100 32
 905 0719 8B45FC   		movl	-4(%rbp), %eax
 906 071c C1E808   		shrl	$8, %eax
 907              		.loc 1 100 38
 908 071f 25FF00FF 		andl	$16711935, %eax
 908      00
 909              		.loc 1 100 7
 910 0724 01D0     		addl	%edx, %eax
 911 0726 8945FC   		movl	%eax, -4(%rbp)
 101:popcount.c    ****     n = (n & 0x0000FFFF) + ((n >> 16) & 0x0000FFFF);
 912              		.loc 1 101 12
 913 0729 8B45FC   		movl	-4(%rbp), %eax
 914 072c 0FB7C0   		movzwl	%ax, %eax
 915              		.loc 1 101 39
 916 072f 8B55FC   		movl	-4(%rbp), %edx
 917 0732 C1EA10   		shrl	$16, %edx
 918              		.loc 1 101 7
 919 0735 01D0     		addl	%edx, %eax
 920 0737 8945FC   		movl	%eax, -4(%rbp)
 102:popcount.c    ****     return n;
 921              		.loc 1 102 12
 922 073a 8B45FC   		movl	-4(%rbp), %eax
 103:popcount.c    **** }
 923              		.loc 1 103 1
 924 073d 5D       		popq	%rbp
 925              		.cfi_def_cfa 7, 8
 926 073e C3       		ret
 927              		.cfi_endproc
 928              	.LFE12:
 930              		.globl	popcount_dnq2
 932              	popcount_dnq2:
 933              	.LFB13:
 104:popcount.c    **** 
 105:popcount.c    **** /* Divide-and-Conquer - improved (15 arithmetic operations) */
 106:popcount.c    **** int popcount_dnq2 (uint32_t n)
 107:popcount.c    **** {
 934              		.loc 1 107 1
 935              		.cfi_startproc
 936 073f F30F1EFA 		endbr64
 937 0743 55       		pushq	%rbp
 938              		.cfi_def_cfa_offset 16
 939              		.cfi_offset 6, -16
 940 0744 4889E5   		movq	%rsp, %rbp
 941              		.cfi_def_cfa_register 6
 942 0747 897DFC   		movl	%edi, -4(%rbp)
 108:popcount.c    ****     n = n - ((n >> 1) & 0x55555555);
 943              		.loc 1 108 17
 944 074a 8B45FC   		movl	-4(%rbp), %eax
 945 074d D1E8     		shrl	%eax
 946              		.loc 1 108 23
 947 074f 25555555 		andl	$1431655765, %eax
 947      55
 948              		.loc 1 108 7
 949 0754 2945FC   		subl	%eax, -4(%rbp)
 109:popcount.c    ****     n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
 950              		.loc 1 109 12
 951 0757 8B45FC   		movl	-4(%rbp), %eax
 952 075a 25333333 		andl	$858993459, %eax
 952      33
 953 075f 89C2     		movl	%eax, %edx
 954              		.loc 1 109 32
 955 0761 8B45FC   		movl	-4(%rbp), %eax
 956 0764 C1E802   		shrl	$2, %eax
 957              		.loc 1 109 38
 958 0767 25333333 		andl	$858993459, %eax
 958      33
 959              		.loc 1 109 7
 960 076c 01D0     		addl	%edx, %eax
 961 076e 8945FC   		movl	%eax, -4(%rbp)
 110:popcount.c    ****     n = (n + (n >> 4)) & 0x0F0F0F0F;
 962              		.loc 1 110 17
 963 0771 8B45FC   		movl	-4(%rbp), %eax
 964 0774 C1E804   		shrl	$4, %eax
 965 0777 89C2     		movl	%eax, %edx
 966              		.loc 1 110 12
 967 0779 8B45FC   		movl	-4(%rbp), %eax
 968 077c 01D0     		addl	%edx, %eax
 969              		.loc 1 110 7
 970 077e 250F0F0F 		andl	$252645135, %eax
 970      0F
 971 0783 8945FC   		movl	%eax, -4(%rbp)
 111:popcount.c    ****     n = n + (n >> 8);
 972              		.loc 1 111 16
 973 0786 8B45FC   		movl	-4(%rbp), %eax
 974 0789 C1E808   		shrl	$8, %eax
 975              		.loc 1 111 7
 976 078c 0145FC   		addl	%eax, -4(%rbp)
 112:popcount.c    ****     n = n + (n >> 16);
 977              		.loc 1 112 16
 978 078f 8B45FC   		movl	-4(%rbp), %eax
 979 0792 C1E810   		shrl	$16, %eax
 980              		.loc 1 112 7
 981 0795 0145FC   		addl	%eax, -4(%rbp)
 113:popcount.c    ****     return n & 0x3F;
 982              		.loc 1 113 14
 983 0798 8B45FC   		movl	-4(%rbp), %eax
 984 079b 83E03F   		andl	$63, %eax
 114:popcount.c    **** }
 985              		.loc 1 114 1
 986 079e 5D       		popq	%rbp
 987              		.cfi_def_cfa 7, 8
 988 079f C3       		ret
 989              		.cfi_endproc
 990              	.LFE13:
 992              		.globl	popcount_dnq3
 994              	popcount_dnq3:
 995              	.LFB14:
 115:popcount.c    **** 
 116:popcount.c    **** /* Divide-and-Conquer - final (12 arithmetic operations) */
 117:popcount.c    **** int popcount_dnq3 (uint32_t n)
 118:popcount.c    **** {
 996              		.loc 1 118 1
 997              		.cfi_startproc
 998 07a0 F30F1EFA 		endbr64
 999 07a4 55       		pushq	%rbp
 1000              		.cfi_def_cfa_offset 16
 1001              		.cfi_offset 6, -16
 1002 07a5 4889E5   		movq	%rsp, %rbp
 1003              		.cfi_def_cfa_register 6
 1004 07a8 897DFC   		movl	%edi, -4(%rbp)
 119:popcount.c    ****     n = n - ((n >> 1) & 0x55555555);
 1005              		.loc 1 119 17
 1006 07ab 8B45FC   		movl	-4(%rbp), %eax
 1007 07ae D1E8     		shrl	%eax
 1008              		.loc 1 119 23
 1009 07b0 25555555 		andl	$1431655765, %eax
 1009      55
 1010              		.loc 1 119 7
 1011 07b5 2945FC   		subl	%eax, -4(%rbp)
 120:popcount.c    ****     n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
 1012              		.loc 1 120 12
 1013 07b8 8B45FC   		movl	-4(%rbp), %eax
 1014 07bb 25333333 		andl	$858993459, %eax
 1014      33
 1015 07c0 89C2     		movl	%eax, %edx
 1016              		.loc 1 120 32
 1017 07c2 8B45FC   		movl	-4(%rbp), %eax
 1018 07c5 C1E802   		shrl	$2, %eax
 1019              		.loc 1 120 38
 1020 07c8 25333333 		andl	$858993459, %eax
 1020      33
 1021              		.loc 1 120 7
 1022 07cd 01D0     		addl	%edx, %eax
 1023 07cf 8945FC   		movl	%eax, -4(%rbp)
 121:popcount.c    ****     n = (n + (n >> 4)) & 0x0F0F0F0F;
 1024              		.loc 1 121 17
 1025 07d2 8B45FC   		movl	-4(%rbp), %eax
 1026 07d5 C1E804   		shrl	$4, %eax
 1027 07d8 89C2     		movl	%eax, %edx
 1028              		.loc 1 121 12
 1029 07da 8B45FC   		movl	-4(%rbp), %eax
 1030 07dd 01D0     		addl	%edx, %eax
 1031              		.loc 1 121 7
 1032 07df 250F0F0F 		andl	$252645135, %eax
 1032      0F
 1033 07e4 8945FC   		movl	%eax, -4(%rbp)
 122:popcount.c    ****     return (n * 0x01010101) >> 24;
 1034              		.loc 1 122 15
 1035 07e7 8B45FC   		movl	-4(%rbp), %eax
 1036 07ea 69C00101 		imull	$16843009, %eax, %eax
 1036      0101
 1037              		.loc 1 122 29
 1038 07f0 C1E818   		shrl	$24, %eax
 123:popcount.c    **** }
 1039              		.loc 1 123 1
 1040 07f3 5D       		popq	%rbp
 1041              		.cfi_def_cfa 7, 8
 1042 07f4 C3       		ret
 1043              		.cfi_endproc
 1044              	.LFE14:
 1046              		.globl	popcount_tab
 1047              		.section	.rodata
 1048              		.align 32
 1051              	popcount_tab:
 1052 0000 00       		.string	""
 1053 0001 01010201 		.ascii	"\001\001\002\001\002\002\003\001\002\002\003\002\003\003\004"
 1053      02020301 
 1053      02020302 
 1053      030304
 1054 0010 01020203 		.ascii	"\001\002\002\003\002\003\003\004\002\003\003\004\003\004\004"
 1054      02030304 
 1054      02030304 
 1054      030404
 1055 001f 05010202 		.ascii	"\005\001\002\002\003\002\003\003\004\002\003\003\004\003\004"
 1055      03020303 
 1055      04020303 
 1055      040304
 1056 002e 04050203 		.ascii	"\004\005\002\003\003\004\003\004\004\005\003\004\004\005\004"
 1056      03040304 
 1056      04050304 
 1056      040504
 1057 003d 05050601 		.ascii	"\005\005\006\001\002\002\003\002\003\003\004\002\003\003\004"
 1057      02020302 
 1057      03030402 
 1057      030304
 1058 004c 03040405 		.ascii	"\003\004\004\005\002\003\003\004\003\004\004\005\003\004\004"
 1058      02030304 
 1058      03040405 
 1058      030404
 1059 005b 05040505 		.ascii	"\005\004\005\005\006\002\003\003\004\003\004\004\005\003\004"
 1059      06020303 
 1059      04030404 
 1059      050304
 1060 006a 04050405 		.ascii	"\004\005\004\005\005\006\003\004\004\005\004\005\005\006\004"
 1060      05060304 
 1060      04050405 
 1060      050604
 1061 0079 05050605 		.ascii	"\005\005\006\005\006\006\007\001\002\002\003\002\003\003\004"
 1061      06060701 
 1061      02020302 
 1061      030304
 1062 0088 02030304 		.ascii	"\002\003\003\004\003\004\004\005\002\003\003\004\003\004\004"
 1062      03040405 
 1062      02030304 
 1062      030404
 1063 0097 05030404 		.ascii	"\005\003\004\004\005\004\005\005\006\002\003\003\004\003\004"
 1063      05040505 
 1063      06020303 
 1063      040304
 1064 00a6 04050304 		.ascii	"\004\005\003\004\004\005\004\005\005\006\003\004\004\005\004"
 1064      04050405 
 1064      05060304 
 1064      040504
 1065 00b5 05050604 		.ascii	"\005\005\006\004\005\005\006\005\006\006\007\002\003\003\004"
 1065      05050605 
 1065      06060702 
 1065      030304
 1066 00c4 03040405 		.ascii	"\003\004\004\005\003\004\004\005\004\005\005\006\003\004\004"
 1066      03040405 
 1066      04050506 
 1066      030404
 1067 00d3 05040505 		.ascii	"\005\004\005\005\006\004\005\005\006\005\006\006\007\003\004"
 1067      06040505 
 1067      06050606 
 1067      070304
 1068 00e2 04050405 		.ascii	"\004\005\004\005\005\006\004\005\005\006\005\006\006\007\004"
 1068      05060405 
 1068      05060506 
 1068      060704
 1069 00f1 05050605 		.ascii	"\005\005\006\005\006\006\007\005\006\006\007\006\007\007\b"
 1069      06060705 
 1069      06060706 
 1069      070708
 1070              		.text
 1071              		.globl	popcount_tablelookup
 1073              	popcount_tablelookup:
 1074              	.LFB15:
 124:popcount.c    **** 
 125:popcount.c    **** const char popcount_tab[256] =
 126:popcount.c    **** {
 127:popcount.c    ****     0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,
 128:popcount.c    ****     1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
 129:popcount.c    ****     1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
 130:popcount.c    ****     2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
 131:popcount.c    ****     1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5,2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,
 132:popcount.c    ****     2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
 133:popcount.c    ****     2,3,3,4,3,4,4,5,3,4,4,5,4,5,5,6,3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,
 134:popcount.c    ****     3,4,4,5,4,5,5,6,4,5,5,6,5,6,6,7,4,5,5,6,5,6,6,7,5,6,6,7,6,7,7,8
 135:popcount.c    **** };
 136:popcount.c    **** 
 137:popcount.c    **** /* Table lookup method */
 138:popcount.c    **** int popcount_tablelookup (uint32_t n)
 139:popcount.c    **** {
 1075              		.loc 1 139 1
 1076              		.cfi_startproc
 1077 07f5 F30F1EFA 		endbr64
 1078 07f9 55       		pushq	%rbp
 1079              		.cfi_def_cfa_offset 16
 1080              		.cfi_offset 6, -16
 1081 07fa 4889E5   		movq	%rsp, %rbp
 1082              		.cfi_def_cfa_register 6
 1083 07fd 897DFC   		movl	%edi, -4(%rbp)
 140:popcount.c    ****     return popcount_tab[n         & 0xFF] +
 1084              		.loc 1 140 35
 1085 0800 8B45FC   		movl	-4(%rbp), %eax
 1086 0803 0FB6C0   		movzbl	%al, %eax
 1087              		.loc 1 140 24
 1088 0806 89C2     		movl	%eax, %edx
 1089 0808 488D0500 		leaq	popcount_tab(%rip), %rax
 1089      000000
 1090 080f 0FB60402 		movzbl	(%rdx,%rax), %eax
 1091 0813 0FBED0   		movsbl	%al, %edx
 141:popcount.c    ****            popcount_tab[(n >>  8) & 0xFF] +
 1092              		.loc 1 141 28
 1093 0816 8B45FC   		movl	-4(%rbp), %eax
 1094 0819 C1E808   		shrl	$8, %eax
 1095              		.loc 1 141 35
 1096 081c 0FB6C0   		movzbl	%al, %eax
 1097              		.loc 1 141 24
 1098 081f 89C1     		movl	%eax, %ecx
 1099 0821 488D0500 		leaq	popcount_tab(%rip), %rax
 1099      000000
 1100 0828 0FB60401 		movzbl	(%rcx,%rax), %eax
 1101 082c 0FBEC0   		movsbl	%al, %eax
 140:popcount.c    ****     return popcount_tab[n         & 0xFF] +
 1102              		.loc 1 140 43
 1103 082f 01C2     		addl	%eax, %edx
 142:popcount.c    ****            popcount_tab[(n >> 16) & 0xFF] +
 1104              		.loc 1 142 28
 1105 0831 8B45FC   		movl	-4(%rbp), %eax
 1106 0834 C1E810   		shrl	$16, %eax
 1107              		.loc 1 142 35
 1108 0837 0FB6C0   		movzbl	%al, %eax
 1109              		.loc 1 142 24
 1110 083a 89C1     		movl	%eax, %ecx
 1111 083c 488D0500 		leaq	popcount_tab(%rip), %rax
 1111      000000
 1112 0843 0FB60401 		movzbl	(%rcx,%rax), %eax
 1113 0847 0FBEC0   		movsbl	%al, %eax
 141:popcount.c    ****            popcount_tab[(n >>  8) & 0xFF] +
 1114              		.loc 1 141 43
 1115 084a 01C2     		addl	%eax, %edx
 143:popcount.c    ****            popcount_tab[(n >> 24)];
 1116              		.loc 1 143 28
 1117 084c 8B45FC   		movl	-4(%rbp), %eax
 1118 084f C1E818   		shrl	$24, %eax
 1119              		.loc 1 143 24
 1120 0852 89C1     		movl	%eax, %ecx
 1121 0854 488D0500 		leaq	popcount_tab(%rip), %rax
 1121      000000
 1122 085b 0FB60401 		movzbl	(%rcx,%rax), %eax
 1123 085f 0FBEC0   		movsbl	%al, %eax
 142:popcount.c    ****            popcount_tab[(n >> 16) & 0xFF] +
 1124              		.loc 1 142 43
 1125 0862 01D0     		addl	%edx, %eax
 144:popcount.c    **** }
 1126              		.loc 1 144 1
 1127 0864 5D       		popq	%rbp
 1128              		.cfi_def_cfa 7, 8
 1129 0865 C3       		ret
 1130              		.cfi_endproc
 1131              	.LFE15:
 1133              		.section	.rodata
 1134              	.LC0:
 1135 0100 30782530 		.string	"0x%08x population count %u\n"
 1135      38782070 
 1135      6F70756C 
 1135      6174696F 
 1135      6E20636F 
 1136              	.LC1:
 1137 011c 706F7063 		.string	"popcount.c"
 1137      6F756E74 
 1137      2E6300
 1138 0127 00       		.align 8
 1139              	.LC2:
 1140 0128 706F7063 		.string	"popcount_common1(num) == count"
 1140      6F756E74 
 1140      5F636F6D 
 1140      6D6F6E31 
 1140      286E756D 
 1141 0147 00       		.align 8
 1142              	.LC3:
 1143 0148 706F7063 		.string	"popcount_common2(num) == count"
 1143      6F756E74 
 1143      5F636F6D 
 1143      6D6F6E32 
 1143      286E756D 
 1144              	.LC4:
 1145 0167 706F7063 		.string	"popcount_fast1(num) == count"
 1145      6F756E74 
 1145      5F666173 
 1145      7431286E 
 1145      756D2920 
 1146              	.LC5:
 1147 0184 706F7063 		.string	"popcount_fast2(num) == count"
 1147      6F756E74 
 1147      5F666173 
 1147      7432286E 
 1147      756D2920 
 1148 01a1 00000000 		.align 8
 1148      000000
 1149              	.LC6:
 1150 01a8 706F7063 		.string	"popcount_fast1_unrolled(num) == count"
 1150      6F756E74 
 1150      5F666173 
 1150      74315F75 
 1150      6E726F6C 
 1151 01ce 0000     		.align 8
 1152              	.LC7:
 1153 01d0 706F7063 		.string	"popcount_fast2_unrolled(num) == count"
 1153      6F756E74 
 1153      5F666173 
 1153      74325F75 
 1153      6E726F6C 
 1154              	.LC8:
 1155 01f6 706F7063 		.string	"popcount_dnq1(num) == count"
 1155      6F756E74 
 1155      5F646E71 
 1155      31286E75 
 1155      6D29203D 
 1156              	.LC9:
 1157 0212 706F7063 		.string	"popcount_dnq2(num) == count"
 1157      6F756E74 
 1157      5F646E71 
 1157      32286E75 
 1157      6D29203D 
 1158              	.LC10:
 1159 022e 706F7063 		.string	"popcount_dnq3(num) == count"
 1159      6F756E74 
 1159      5F646E71 
 1159      33286E75 
 1159      6D29203D 
 1160 024a 00000000 		.align 8
 1160      0000
 1161              	.LC11:
 1162 0250 706F7063 		.string	"popcount_tablelookup(num) == count"
 1162      6F756E74 
 1162      5F746162 
 1162      6C656C6F 
 1162      6F6B7570 
 1163              		.text
 1164              		.globl	main
 1166              	main:
 1167              	.LFB16:
 145:popcount.c    **** 
 146:popcount.c    **** int main ()
 147:popcount.c    **** {
 1168              		.loc 1 147 1
 1169              		.cfi_startproc
 1170 0866 F30F1EFA 		endbr64
 1171 086a 55       		pushq	%rbp
 1172              		.cfi_def_cfa_offset 16
 1173              		.cfi_offset 6, -16
 1174 086b 4889E5   		movq	%rsp, %rbp
 1175              		.cfi_def_cfa_register 6
 1176 086e 4883EC10 		subq	$16, %rsp
 148:popcount.c    ****     uint32_t num, count;
 149:popcount.c    **** 
 150:popcount.c    ****     srandom(time(NULL));
 1177              		.loc 1 150 13
 1178 0872 BF000000 		movl	$0, %edi
 1178      00
 1179 0877 E8000000 		call	time@PLT
 1179      00
 1180              		.loc 1 150 5
 1181 087c 89C7     		movl	%eax, %edi
 1182 087e E8000000 		call	srandom@PLT
 1182      00
 1183              	.LBB2:
 151:popcount.c    ****     for (int i=1; i<16; i++) {
 1184              		.loc 1 151 14
 1185 0883 C745F401 		movl	$1, -12(%rbp)
 1185      000000
 1186              		.loc 1 151 5
 1187 088a E9150200 		jmp	.L95
 1187      00
 1188              	.L106:
 152:popcount.c    ****         /*
 153:popcount.c    ****          * Note RAND_MAX here is 0x7FFFFFFF (2^31-1), so need to
 154:popcount.c    ****          * run two steps to generate single 32-bit random number.
 155:popcount.c    ****          */
 156:popcount.c    ****         num = random() & 0xFFFF;
 1189              		.loc 1 156 15
 1190 088f E8000000 		call	random@PLT
 1190      00
 1191              		.loc 1 156 13
 1192 0894 25FFFF00 		andl	$65535, %eax
 1192      00
 1193 0899 8945F8   		movl	%eax, -8(%rbp)
 157:popcount.c    ****         num |= (random() & 0xFFFF) << 16;
 1194              		.loc 1 157 17
 1195 089c E8000000 		call	random@PLT
 1195      00
 1196              		.loc 1 157 36
 1197 08a1 48C1E010 		salq	$16, %rax
 1198 08a5 250000FF 		andl	$4294901760, %eax
 1198      FF
 1199              		.loc 1 157 13
 1200 08aa 89C2     		movl	%eax, %edx
 1201 08ac 8B45F8   		movl	-8(%rbp), %eax
 1202 08af 09D0     		orl	%edx, %eax
 1203 08b1 8945F8   		movl	%eax, -8(%rbp)
 158:popcount.c    **** 
 159:popcount.c    ****         count = __builtin_popcount(num);
 1204              		.loc 1 159 17
 1205 08b4 F30FB845 		popcntl	-8(%rbp), %eax
 1205      F8
 1206              		.loc 1 159 15
 1207 08b9 8945FC   		movl	%eax, -4(%rbp)
 160:popcount.c    ****         printf("0x%08x population count %u\n", num, count);
 1208              		.loc 1 160 9
 1209 08bc 8B55FC   		movl	-4(%rbp), %edx
 1210 08bf 8B45F8   		movl	-8(%rbp), %eax
 1211 08c2 89C6     		movl	%eax, %esi
 1212 08c4 488D3D00 		leaq	.LC0(%rip), %rdi
 1212      000000
 1213 08cb B8000000 		movl	$0, %eax
 1213      00
 1214 08d0 E8000000 		call	printf@PLT
 1214      00
 161:popcount.c    ****         assert(popcount_common1(num) == count);
 1215              		.loc 1 161 9
 1216 08d5 8B45F8   		movl	-8(%rbp), %eax
 1217 08d8 89C7     		movl	%eax, %edi
 1218 08da E8000000 		call	popcount_common1
 1218      00
 1219 08df 3945FC   		cmpl	%eax, -4(%rbp)
 1220 08e2 741F     		je	.L96
 1221              		.loc 1 161 9 is_stmt 0 discriminator 1
 1222 08e4 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1222      000000
 1223 08eb BAA10000 		movl	$161, %edx
 1223      00
 1224 08f0 488D3500 		leaq	.LC1(%rip), %rsi
 1224      000000
 1225 08f7 488D3D00 		leaq	.LC2(%rip), %rdi
 1225      000000
 1226 08fe E8000000 		call	__assert_fail@PLT
 1226      00
 1227              	.L96:
 162:popcount.c    ****         assert(popcount_common2(num) == count);
 1228              		.loc 1 162 9 is_stmt 1
 1229 0903 8B45F8   		movl	-8(%rbp), %eax
 1230 0906 89C7     		movl	%eax, %edi
 1231 0908 E8000000 		call	popcount_common2
 1231      00
 1232 090d 3945FC   		cmpl	%eax, -4(%rbp)
 1233 0910 741F     		je	.L97
 1234              		.loc 1 162 9 is_stmt 0 discriminator 1
 1235 0912 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1235      000000
 1236 0919 BAA20000 		movl	$162, %edx
 1236      00
 1237 091e 488D3500 		leaq	.LC1(%rip), %rsi
 1237      000000
 1238 0925 488D3D00 		leaq	.LC3(%rip), %rdi
 1238      000000
 1239 092c E8000000 		call	__assert_fail@PLT
 1239      00
 1240              	.L97:
 163:popcount.c    ****         assert(popcount_fast1(num) == count);
 1241              		.loc 1 163 9 is_stmt 1
 1242 0931 8B45F8   		movl	-8(%rbp), %eax
 1243 0934 89C7     		movl	%eax, %edi
 1244 0936 E8000000 		call	popcount_fast1
 1244      00
 1245 093b 3945FC   		cmpl	%eax, -4(%rbp)
 1246 093e 741F     		je	.L98
 1247              		.loc 1 163 9 is_stmt 0 discriminator 1
 1248 0940 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1248      000000
 1249 0947 BAA30000 		movl	$163, %edx
 1249      00
 1250 094c 488D3500 		leaq	.LC1(%rip), %rsi
 1250      000000
 1251 0953 488D3D00 		leaq	.LC4(%rip), %rdi
 1251      000000
 1252 095a E8000000 		call	__assert_fail@PLT
 1252      00
 1253              	.L98:
 164:popcount.c    ****         assert(popcount_fast2(num) == count);
 1254              		.loc 1 164 9 is_stmt 1
 1255 095f 8B45F8   		movl	-8(%rbp), %eax
 1256 0962 89C7     		movl	%eax, %edi
 1257 0964 E8000000 		call	popcount_fast2
 1257      00
 1258 0969 3945FC   		cmpl	%eax, -4(%rbp)
 1259 096c 741F     		je	.L99
 1260              		.loc 1 164 9 is_stmt 0 discriminator 1
 1261 096e 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1261      000000
 1262 0975 BAA40000 		movl	$164, %edx
 1262      00
 1263 097a 488D3500 		leaq	.LC1(%rip), %rsi
 1263      000000
 1264 0981 488D3D00 		leaq	.LC5(%rip), %rdi
 1264      000000
 1265 0988 E8000000 		call	__assert_fail@PLT
 1265      00
 1266              	.L99:
 165:popcount.c    ****         assert(popcount_fast1_unrolled(num) == count);
 1267              		.loc 1 165 9 is_stmt 1
 1268 098d 8B45F8   		movl	-8(%rbp), %eax
 1269 0990 89C7     		movl	%eax, %edi
 1270 0992 E8000000 		call	popcount_fast1_unrolled
 1270      00
 1271 0997 3945FC   		cmpl	%eax, -4(%rbp)
 1272 099a 741F     		je	.L100
 1273              		.loc 1 165 9 is_stmt 0 discriminator 1
 1274 099c 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1274      000000
 1275 09a3 BAA50000 		movl	$165, %edx
 1275      00
 1276 09a8 488D3500 		leaq	.LC1(%rip), %rsi
 1276      000000
 1277 09af 488D3D00 		leaq	.LC6(%rip), %rdi
 1277      000000
 1278 09b6 E8000000 		call	__assert_fail@PLT
 1278      00
 1279              	.L100:
 166:popcount.c    ****         assert(popcount_fast2_unrolled(num) == count);
 1280              		.loc 1 166 9 is_stmt 1
 1281 09bb 8B45F8   		movl	-8(%rbp), %eax
 1282 09be 89C7     		movl	%eax, %edi
 1283 09c0 E8000000 		call	popcount_fast2_unrolled
 1283      00
 1284 09c5 3945FC   		cmpl	%eax, -4(%rbp)
 1285 09c8 741F     		je	.L101
 1286              		.loc 1 166 9 is_stmt 0 discriminator 1
 1287 09ca 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1287      000000
 1288 09d1 BAA60000 		movl	$166, %edx
 1288      00
 1289 09d6 488D3500 		leaq	.LC1(%rip), %rsi
 1289      000000
 1290 09dd 488D3D00 		leaq	.LC7(%rip), %rdi
 1290      000000
 1291 09e4 E8000000 		call	__assert_fail@PLT
 1291      00
 1292              	.L101:
 167:popcount.c    ****         assert(popcount_dnq1(num) == count);
 1293              		.loc 1 167 9 is_stmt 1
 1294 09e9 8B45F8   		movl	-8(%rbp), %eax
 1295 09ec 89C7     		movl	%eax, %edi
 1296 09ee E8000000 		call	popcount_dnq1
 1296      00
 1297 09f3 3945FC   		cmpl	%eax, -4(%rbp)
 1298 09f6 741F     		je	.L102
 1299              		.loc 1 167 9 is_stmt 0 discriminator 1
 1300 09f8 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1300      000000
 1301 09ff BAA70000 		movl	$167, %edx
 1301      00
 1302 0a04 488D3500 		leaq	.LC1(%rip), %rsi
 1302      000000
 1303 0a0b 488D3D00 		leaq	.LC8(%rip), %rdi
 1303      000000
 1304 0a12 E8000000 		call	__assert_fail@PLT
 1304      00
 1305              	.L102:
 168:popcount.c    ****         assert(popcount_dnq2(num) == count);
 1306              		.loc 1 168 9 is_stmt 1
 1307 0a17 8B45F8   		movl	-8(%rbp), %eax
 1308 0a1a 89C7     		movl	%eax, %edi
 1309 0a1c E8000000 		call	popcount_dnq2
 1309      00
 1310 0a21 3945FC   		cmpl	%eax, -4(%rbp)
 1311 0a24 741F     		je	.L103
 1312              		.loc 1 168 9 is_stmt 0 discriminator 1
 1313 0a26 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1313      000000
 1314 0a2d BAA80000 		movl	$168, %edx
 1314      00
 1315 0a32 488D3500 		leaq	.LC1(%rip), %rsi
 1315      000000
 1316 0a39 488D3D00 		leaq	.LC9(%rip), %rdi
 1316      000000
 1317 0a40 E8000000 		call	__assert_fail@PLT
 1317      00
 1318              	.L103:
 169:popcount.c    ****         assert(popcount_dnq3(num) == count);
 1319              		.loc 1 169 9 is_stmt 1
 1320 0a45 8B45F8   		movl	-8(%rbp), %eax
 1321 0a48 89C7     		movl	%eax, %edi
 1322 0a4a E8000000 		call	popcount_dnq3
 1322      00
 1323 0a4f 3945FC   		cmpl	%eax, -4(%rbp)
 1324 0a52 741F     		je	.L104
 1325              		.loc 1 169 9 is_stmt 0 discriminator 1
 1326 0a54 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1326      000000
 1327 0a5b BAA90000 		movl	$169, %edx
 1327      00
 1328 0a60 488D3500 		leaq	.LC1(%rip), %rsi
 1328      000000
 1329 0a67 488D3D00 		leaq	.LC10(%rip), %rdi
 1329      000000
 1330 0a6e E8000000 		call	__assert_fail@PLT
 1330      00
 1331              	.L104:
 170:popcount.c    ****         assert(popcount_tablelookup(num) == count);
 1332              		.loc 1 170 9 is_stmt 1
 1333 0a73 8B45F8   		movl	-8(%rbp), %eax
 1334 0a76 89C7     		movl	%eax, %edi
 1335 0a78 E8000000 		call	popcount_tablelookup
 1335      00
 1336 0a7d 3945FC   		cmpl	%eax, -4(%rbp)
 1337 0a80 741F     		je	.L105
 1338              		.loc 1 170 9 is_stmt 0 discriminator 1
 1339 0a82 488D0D00 		leaq	__PRETTY_FUNCTION__.3498(%rip), %rcx
 1339      000000
 1340 0a89 BAAA0000 		movl	$170, %edx
 1340      00
 1341 0a8e 488D3500 		leaq	.LC1(%rip), %rsi
 1341      000000
 1342 0a95 488D3D00 		leaq	.LC11(%rip), %rdi
 1342      000000
 1343 0a9c E8000000 		call	__assert_fail@PLT
 1343      00
 1344              	.L105:
 151:popcount.c    ****         /*
 1345              		.loc 1 151 26 is_stmt 1 discriminator 2
 1346 0aa1 FF45F4   		incl	-12(%rbp)
 1347              	.L95:
 151:popcount.c    ****         /*
 1348              		.loc 1 151 5 discriminator 1
 1349 0aa4 837DF40F 		cmpl	$15, -12(%rbp)
 1350 0aa8 0F8EE1FD 		jle	.L106
 1350      FFFF
 1351              	.LBE2:
 171:popcount.c    ****     }
 172:popcount.c    ****     return 0;
 1352              		.loc 1 172 12
 1353 0aae B8000000 		movl	$0, %eax
 1353      00
 173:popcount.c    **** }
 1354              		.loc 1 173 1
 1355 0ab3 C9       		leave
 1356              		.cfi_def_cfa 7, 8
 1357 0ab4 C3       		ret
 1358              		.cfi_endproc
 1359              	.LFE16:
 1361              		.section	.rodata
 1364              	__PRETTY_FUNCTION__.3498:
 1365 0273 6D61696E 		.string	"main"
 1365      00
 1366              		.text
 1367              	.Letext0:
 1368              		.file 2 "/usr/lib/gcc/x86_64-linux-gnu/9/include/stddef.h"
 1369              		.file 3 "/usr/include/x86_64-linux-gnu/bits/types.h"
 1370              		.file 4 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h"
 1371              		.file 5 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h"
 1372              		.file 6 "/usr/include/stdio.h"
 1373              		.file 7 "/usr/include/x86_64-linux-gnu/bits/sys_errlist.h"
 1374              		.file 8 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h"
 1375              		.file 9 "/usr/include/time.h"
 2689              		.section	.note.gnu.property,"a"
 2690              		.align 8
 2691 0000 04000000 		.long	 1f - 0f
 2692 0004 10000000 		.long	 4f - 1f
 2693 0008 05000000 		.long	 5
 2694              	0:
 2695 000c 474E5500 		.string	 "GNU"
 2696              	1:
 2697              		.align 8
 2698 0010 020000C0 		.long	 0xc0000002
 2699 0014 04000000 		.long	 3f - 2f
 2700              	2:
 2701 0018 03000000 		.long	 0x3
 2702              	3:
 2703 001c 00000000 		.align 8
 2704              	4:
