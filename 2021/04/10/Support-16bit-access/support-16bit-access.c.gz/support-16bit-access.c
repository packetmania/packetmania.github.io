/*
 * PakcteMania https://packetmania.github.io
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>

typedef enum {
    CONF_8BIT_ACCESS = 1,
    CONF_16BIT_ACCESS = 2
} conf_access_type;

int test_endian() {
    int x = 1;
    return *((char *)&x);
}

void write_conf_byte (char *confaddr, char c, conf_access_type type)
{
    ushort *d_16;

    if (type == CONF_16BIT_ACCESS) {
        d_16 = (ushort *)((uintptr_t)confaddr & (~0x1));
        if ((((uintptr_t)confaddr & 0x01) && (test_endian() == 0)) ||
            ((((uintptr_t)confaddr & 0x01) == 0) && test_endian())) {
            /* (odd address + big endian) or (even address + little endian) */
            *d_16 = (*d_16 & 0xFF00) | c;
        } else {
            *d_16 = (*d_16 & 0x00FF) | (c<<8);
        }
    } else { /* CONF_8BIT_ACCESS */
        *confaddr = c;
    }
}

int main() {
    char *buffer8, *buffer16;

    printf("%s Endian system\n", test_endian() ? "Little" : "Big");
    buffer8 = calloc(4, 1);
    buffer16 = calloc(4, 1);

    for (int i=0; i<4; i++) {
         write_conf_byte(buffer8+i, (char)i, CONF_8BIT_ACCESS);
         write_conf_byte(buffer16+i, (char)i, CONF_16BIT_ACCESS);
    }

    assert(*(uint *)buffer8 == *(uint *)buffer16);
    printf("Buffer content: 0x%08x\n", *(uint *)buffer16);
    return 0;
}
