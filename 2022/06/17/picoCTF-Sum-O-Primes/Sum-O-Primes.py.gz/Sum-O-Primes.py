import math


file = open('output.txt', 'r')
Lines = file.readlines()
file.close()

x = int((Lines[0].split())[2], 16) # x = p + q
n = int((Lines[1].split())[2], 16) # n = p * q
c = int((Lines[2].split())[2], 16) # Ciphertext

# To solve p and q, convert it to a quadratic equation:
#
# (1) q = x - p
# (2) p * (x - p) = n
# (3) p^2 - x * p + n = 0
#
# Apparently p and q are the two solutions of (3)
#
# (p,q) = (x +/- sqrt(x^2 - 4 * n) / 2
#       = x/2 +/- sqrt((x/2)^2 - n)

def solve_rsa_primes(s: int, m: int) -> tuple:
    '''
    Solve RSA prime numbers (p, q) from the quadratic equation
    p^2 - s * p + m = 0 with the formula p = s/2 +/- sqrt((s/2)^2 - m)

    Input: s - sum of primes, m - product of primes
    Output: (p, q)
    '''
    half_s = s >> 1
    tmp = math.isqrt(half_s ** 2 - m)
    return int(half_s + tmp), int(half_s - tmp);

# Test code for the solution of the quadratic equation
p, q = 5867, 127
p1, q1 = solve_rsa_primes(127 + 5867, 127 * 5867)
assert(p1 == p and q1 == q)     

# Now run with the real input
p, q = solve_rsa_primes(x, n)
x1 = p + q
n1 = p * q
print("p' =", p)
print("q' =", q)

print("x  =", x)
print("x1 =", x1)
print("n  =", n)
print("n1 =", n1)
assert(x == x1 and n == n1)

m = math.lcm(p - 1, q - 1)
e = 65537
d = pow(e, -1, m)
FLAG = pow(c, d, n)
print(FLAG.to_bytes((FLAG.bit_length() + 7) // 8, 'big'))

# A fast solution - find the d with Euler totient function
# as defined in the original RSA paper:
#
#     d * e ≡ 1 mod (phi(n))
# =>  d ≡ e^(-1) mod (phi(p * q))
# =>  d ≡ e^(-1) mod ((p -1)(q - 1))
#
# So if we can find out phi(p * q), there is no need to know
# the exact p and q!
#
# phi(n) = phi(p * q) = (p - 1)(q - 1) = p * q - (p + q) +1
#        = n - x + 1
d1 = pow(e, -1, n - x + 1)
FLAG1 = pow(c, d1, n)
print(FLAG1.to_bytes((FLAG1.bit_length() + 7) // 8, 'big'))

print("d =", d)
print("d1 =", d1)
assert(d1 > d)
print("d1/d =", d1/d)
