#include <iostream>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h> 
#include <string.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/types.h> 

using namespace std;

#define MAXLEN 1024
#define HNAMELEN 50

// This is header message to each router to tell it its own
// ID and how many neighbors it has.
struct message {
  int routerId;
  int numNeighbor;
};

// This message is used for the manager to tell each router
// its neighbor information including <id, cost, UDP_port>.
struct nb_tuple {
  int neighborId;
  int cost;
  int UDP_port;
};

