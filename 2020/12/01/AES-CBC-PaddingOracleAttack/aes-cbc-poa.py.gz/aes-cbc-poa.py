# https://www.packetmania.net (International)
# https://blog.packetmania.net (China-HongKong)

from random import choice, randint
from os import urandom
from string import printable
from binascii import hexlify

from cryptography.hazmat.primitives.ciphers import Cipher
from cryptography.hazmat.primitives.ciphers.algorithms import AES
from cryptography.hazmat.primitives.ciphers.modes import ECB
from cryptography.hazmat.backends import default_backend

# Original Paper:
# Vaudenay S. (2002) Security Flaws Induced by CBC Padding — Applications to SSL, IPSEC, WTLS...
#     In: Knudsen L.R. (eds) Advances in Cryptology — EUROCRYPT 2002.


AES_128_BLOCK_SIZE = 16


def bytes_xor(x, y):
    '''XOR two given byte strings of same length'''
    ret = b''
    for b1, b2 in zip(x, y):
        ret += bytes([b1 ^ b2])
    return ret


def split_bytes_blocks(bytes_str, block_size=AES_128_BLOCK_SIZE):
    '''
    Split bytes into blocks for given block size, note the
    last block might be a short one if the total length is
    not a multiple of block size.
    '''
    return [bytes_str[i:i + block_size]
            for i in range(0, len(bytes_str), block_size)]


def get_random_string(length):
    '''
    Return random string of given length. String has the
    combination of all printable ASCII characters.
    '''
    return ''.join(choice(printable) for _ in range(length))


def pkcs7_padding(data, block_size=AES_128_BLOCK_SIZE):
    padding_length = block_size - len(data) % block_size
    return data + bytes([padding_length]) * padding_length


class PaddingError(Exception):
    pass


def pkcs7_stripping(data, block_size=AES_128_BLOCK_SIZE):
    if len(data) % block_size > 0:
        raise PaddingError

    padding_length = data[-1]
    if padding_length > block_size or padding_length < 1:
        raise PaddingError

    if not data.endswith(bytes([padding_length]) * padding_length):
        raise PaddingError

    return data[:-padding_length]


def pkcs7_padding_oracle(data, block_size=AES_128_BLOCK_SIZE):
    '''Padding Oracle API: return False for bad padding'''
    padding_length = data[-1]
    if padding_length > block_size or padding_length < 1:
        ret = False
    elif not data.endswith(bytes([padding_length]) * padding_length):
        ret = False
    else:
        ret = True
    return ret


def aes_128_encrypt(key, msg_block):
    '''
    Single 128-byte block AES encryption leveraging Cryptography
    library Cipher object AES-ECB APIs
    '''
    aes_cipher = Cipher(AES(key), ECB(), default_backend())
    aes_encryptor = aes_cipher.encryptor()
    return aes_encryptor.update(msg_block) + aes_encryptor.finalize()


def aes_128_decrypt(key, cipher_block):
    '''
    Single 128-byte block AES decryption leveraging Cryptography
    library Cipher object AES-ECB APIs
    '''
    aes_cipher = Cipher(AES(key), ECB(), default_backend())
    aes_decryptor = aes_cipher.decryptor()
    return aes_decryptor.update(cipher_block) + aes_decryptor.finalize()


def aes_128_cbc_encrypt(iv, key, msg_text):
    '''AES-CBC-128 encryption with given IV and Key'''
    # padding then split the cipher_text to block of size 16-bytes
    msg_text = pkcs7_padding(msg_text, AES_128_BLOCK_SIZE)
    blocks = split_bytes_blocks(msg_text)

    prev = iv
    cipher_text = b''
    for block in blocks:
        block = bytes_xor(prev, block)
        encipher = aes_128_encrypt(key, block)
        prev = encipher
        cipher_text += encipher
    return cipher_text


def aes_128_cbc_decrypt_oracle(iv, key, cipher_text):
    '''
    AES-CBC-128 decryption with given IV and Key then do padding oracle:
    Return boolean:
        True  : Decrypted plain text has valid padding
        False : Padding error seen with plain text decrypted
    ''' 
    # split the cipher_text to block of size 16-bytes
    blocks = split_bytes_blocks(cipher_text)

    prev = iv
    plain_text = b''
    for block in blocks:
        decipher = aes_128_decrypt(key, block)
        plain_text += bytes_xor(prev, decipher)
        prev = block
    return pkcs7_padding_oracle(plain_text)


# Now we attack the AES-CBC-128 cipher text!
#
# The basic approach is to manipulate previous block of ciphertext,
# so forge a new last plain text block to feed CBC padding oracle.
# When it returns no padding error, we have a good guess of the
# corresponding character.
#
# 1. To target ending byte of the tail block: 'X X X X X X X X X X X X X X X T'
#    Note 'T' must be one of 1 or 16 for good padding.
#
#    Since P(n) = P'(n)^C(n-1) for the last byte, if we change C(n-1) to
#    C(n-1) ^ 1 ^ { 0 - 255 } // looping through 0 to 255, we get
#
#        P'(n)^ C(n-1) ^ 1 ^ { 0 - 255 } = P(n) ^ 1 ^ { 0 - 256 }
#
#    So only when P(n) == { 0 - 256 }, we get a good padding byte 1 at the end.
#
# 2. Expanding the same idea to the 2nd to the last byte:
#
#    We first change the last byte to 2: 'X X X X X X X X X X X X X X T 2'
#    Now change C(n-1) to C(n-1) ^ 2 ^ { 0 - 255 } for target byte T:
#
#        P'(n)^ C(n-1) ^ 2 ^ { 0 - 255 } = P(n) ^ 2 ^ { 0 - 255 }
#
#    Only when P(n) == { 0 - 255 }, we will get a good padding bytes dual
#    2 2 at the end.
#
# 3. Repeat this for all the remaining bytes in the block, using
#    C(n-1) ^ [ 3 - 16 ] ^ { 0 - 255 } each round.
#
# 4. To facilitate decoding the 1st block, we prepend IV to the cipher block
#    list as C(-1).


# To target the last block with some padding bytes. We preset
# the padding bytes to be the next value. E.g padding byte 3:
# ----------------------------------------------------------------
#  i  Byte Index Byte list                           Target Value
# ----------------------------------------------------------------
#  0  13         X X X X X X X X X X X X T 4 4 4     4
#  1  12         X X X X X X X X X X X T 5 5 5 5     5
#  2  11         X X X X X X X X X X T 6 6 6 6 6     6
#  ...
#  12 1          X T  15 15 ................. 15 15  15
#  13 0          T 16 16 16.................. 16 16  16
# ----------------------------------------------------------------
#
# For previous blocks, to target the i-th byte from the end, we need
# to initialize the last i byte(s) as i+1 first.
# ----------------------------------------------------------------
#  i  Byte Index  Byte list                           Target Value
# ----------------------------------------------------------------
#  0  15          X X X X X X X X X X X X X X X T     1
#  1  14          X X X X X X X X X X X X X X T 2     2
#  2  13          X X X X X X X X X X X X X T 3 3     3
#  ...
#  14 1           X T  15 15 ................ 15 15   15
#  15 0           T 16 16 ................... 16 16   16
# ----------------------------------------------------------------
#
# Last, we generalize one single function to handle both cases.
# We pass padding length as last parameter here to treat non-padding
# case as a special padding length 0 case. The process is the same.
def crack_cipher_block(prev_ctxt, curr_ctxt, iv, key, plen):
    '''
    This function takes two cipher blocks and forge the 1st one to
    hack out the plain text of the 2nd block, one byte at a time.
    Return the cracked plain text of the 2nd block.
    Input:
        prev_ctxt  The previous ciphertext block
        curr_ctxt  The current ciphertext block as the target
        iv         16-byte AES-128 IV
        key        16-byte AES-128 Key
        plen       The padding length of the target block
    Output:
        Byte array of the plain text block
    '''
    plain_txt = bytearray(16)

    if plen == 16:
        return b'\x10' * 16

    # This is to crack last block. First time we need to set all
    # last plen bytes of plain_txt to the value of plen.
    if plen != 0:
        plain_txt[-plen:] = [plen] * plen

    for i in range(16 - plen):
        # The target byte index is (16-plen-i-1)
        # First presetting the bytes behind the target byte
        prev_array = bytearray(prev_ctxt)
        for j in range(plen + i):
            prev_array[-j - 1] ^= (plen + i + 1) ^ plain_txt[-j - 1]

        # Now cracking the target byte
        target_original = prev_array[-plen - i - 1]
        for k in range(256):
            prev_array[-plen - i - 1] = target_original ^ (k ^ (plen + i + 1))
            feed_ctxt = bytes(prev_array) + curr_ctxt
            # feed to padding oracle
            if aes_128_cbc_decrypt_oracle(iv, key, feed_ctxt):
                plain_txt[15 - plen - i] = k
                break

    return bytes(plain_txt)


def crack_padding_length(seclast_cblock, ending_cblock, iv, key):
    '''
    This function returns the padding length in the ending ciphertext
    block. It needs last two ciphertext blocks. The input IV and key
    are passed to the AES-CBC-128 padding oracle function invoked inside.

    To find out the padding length, it starts from the 1st byte of the
    ending block and makes single byte change each round via scrambling
    the corresponding byte of the penultimate block because

        P(n) = D(C(n), k) ^ C(n-1)

    The forged ciphertext blocks are fed to the oracle. If that returns
    False, meaning it breaks the padding rule, the padding length would
    be BLOCK size minus the index from the left.
    '''
    c_array = bytearray(seclast_cblock)
    padding_len = 0
    for i in range(16):
        c_array[i] ^= 16
        feed_ctxt = bytes(c_array) + ending_cblock
        if not aes_128_cbc_decrypt_oracle(iv, key, feed_ctxt):
            padding_len = 16 - i
            break
    return padding_len


ptxt = get_random_string(randint(10,100));
p_bytes = bytes(ptxt, 'utf-8')
p_len = 16 - len(p_bytes) % 16
iv = urandom(16)
key = urandom(16)
ctxt = aes_128_cbc_encrypt(iv, key, p_bytes)

print("Plaintext: ", p_bytes);
print("Ciphertext:", hexlify(ctxt));

# Split and prepend IV for normalized processing
c_blocks = split_bytes_blocks(ctxt)
c_blocks = [bytes(iv)] + c_blocks

# Find the exact padding length in the last block
padding_len = crack_padding_length(c_blocks[-2], c_blocks[-1], iv, key)
print("\nPlaintext length:      ", len(p_bytes));
print("Cracked padding length:", padding_len)
assert padding_len == p_len

cracked_ptxt = b''
for m in range(len(c_blocks) - 1):
    if m != 0:
        padding_len = 0
    cracked_block = crack_cipher_block(c_blocks[-m - 2], c_blocks[-m - 1],
                                       iv, key, padding_len)
    cracked_ptxt = cracked_block + cracked_ptxt

cracked_bytes = pkcs7_stripping(cracked_ptxt)
print("Cracked plaintext:\n", cracked_bytes)
assert p_bytes == cracked_bytes
